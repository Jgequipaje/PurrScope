(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0j5_5.a._.js","static/chunks/lib_0-q3bk0._.js"],
    source: "dynamic"
});
