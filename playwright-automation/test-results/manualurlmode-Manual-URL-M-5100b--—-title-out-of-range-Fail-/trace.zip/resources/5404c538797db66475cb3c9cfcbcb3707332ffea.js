(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/ModeTabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModeTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const LABELS = {
    manual: "Manual URLs",
    sitemap: "Sitemap Crawl"
};
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ModeTabs__Wrap",
    componentId: "sc-c2866a9d-0"
})`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 1.25rem;

  @media (min-width: 480px) {
    flex-direction: row;
    gap: 6px;
  }
`;
_c = Wrap;
const Tab = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ModeTabs__Tab",
    componentId: "sc-c2866a9d-1"
})`
  width: 100%;
  padding: 10px 16px;
  font-size: 14px;
  font-weight: 600;
  border-radius: 8px;
  border: 1px solid ${(p)=>p.$border};
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  background: ${(p)=>p.$active ? p.$activeBg : p.$bg};
  color: ${(p)=>p.$active ? p.$activeColor : p.$color};
  font-family: inherit;
  opacity: ${(p)=>p.$disabled && !p.$active ? 0.45 : 1};
  transition: background 0.15s, opacity 0.15s, transform 0.1s;
  &:not([disabled]):hover { opacity: 0.85; }
  &:not([disabled]):active { transform: scale(0.97); }

  @media (min-width: 480px) {
    width: auto;
    padding: 6px 16px;
  }
`;
_c1 = Tab;
function ModeTabs({ mode, onChange, disabled = false }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        children: Object.keys(LABELS).map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tab, {
                onClick: ()=>!disabled && onChange(m),
                $active: mode === m,
                $bg: t.btnIdle,
                $activeBg: t.btnActive,
                $color: t.btnIdleTxt,
                $activeColor: t.btnActiveTxt,
                $border: t.border,
                $disabled: disabled,
                children: LABELS[m]
            }, m, false, {
                fileName: "[project]/components/ModeTabs.tsx",
                lineNumber: 60,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/ModeTabs.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_s(ModeTabs, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c2 = ModeTabs;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "Tab");
__turbopack_context__.k.register(_c2, "ModeTabs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ManualInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ManualInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const MAX_URLS = 10;
const Textarea = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].textarea.withConfig({
    displayName: "ManualInput__Textarea",
    componentId: "sc-f5a5abca-0"
})`
  width: 100%;
  padding: 0.65rem 0.9rem;
  font-size: 14px;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  resize: vertical;
  font-family: inherit;
  box-sizing: border-box;
  margin-bottom: 6px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$text};
  transition: opacity 0.15s;
  &:disabled {
    opacity: 0.55;
    cursor: not-allowed;
    resize: none;
  }
`;
_c = Textarea;
const Counter = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ManualInput__Counter",
    componentId: "sc-f5a5abca-1"
})`
  font-size: 12px;
  margin-bottom: 1rem;
  color: ${(p)=>p.$warn ? p.$warnColor : p.$mutedColor};
`;
_c1 = Counter;
const ScanButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ManualInput__ScanButton",
    componentId: "sc-f5a5abca-2"
})`
  padding: 0.6rem 1.5rem;
  font-size: 15px;
  font-weight: 600;
  background: ${(p)=>p.$disabled ? "#9ca3af" : "#2563eb"};
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  margin-bottom: 1.75rem;
  font-family: inherit;
  width: 100%;
  transition: background 0.15s, opacity 0.15s, transform 0.1s;
  &:not(:disabled):hover { background: #1d4ed8; }
  &:not(:disabled):active { transform: scale(0.97); }

  @media (min-width: 540px) {
    width: auto;
  }
`;
_c2 = ScanButton;
const CancelButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ManualInput__CancelButton",
    componentId: "sc-f5a5abca-3"
})`
  padding: 0.6rem 1.1rem;
  font-size: 14px;
  font-weight: 600;
  background: transparent;
  color: #b91c1c;
  border: 1px solid #b91c1c;
  border-radius: 8px;
  cursor: pointer;
  margin-bottom: 1.75rem;
  font-family: inherit;
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: background 0.15s, transform 0.1s;
  &:hover { background: #fee2e2; }
  &:active { transform: scale(0.97); }

  @media (min-width: 540px) {
    width: auto;
  }
`;
_c3 = CancelButton;
function ManualInput({ value, onChange, onScan, onCancel, loading, isProcessing }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const count = value.split("\n").map((u)=>u.trim()).filter(Boolean).length;
    const atLimit = count >= MAX_URLS;
    const disabled = loading || count === 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Textarea, {
                rows: 5,
                placeholder: "https://example.com\nhttps://example.com/about\nhttps://example.com/contact",
                value: value,
                onChange: (e)=>onChange(e.target.value),
                disabled: isProcessing,
                $border: t.border,
                $bg: t.bg,
                $text: t.text
            }, void 0, false, {
                fileName: "[project]/components/ManualInput.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Counter, {
                $warn: atLimit,
                $warnColor: t.failText,
                $mutedColor: t.textFaint,
                children: [
                    count,
                    " / ",
                    MAX_URLS,
                    " URLs",
                    atLimit && " — limit reached, remove a URL to add another"
                ]
            }, void 0, true, {
                fileName: "[project]/components/ManualInput.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CancelButton, {
                onClick: onCancel,
                type: "button",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseLine"], {
                        size: 15
                    }, void 0, false, {
                        fileName: "[project]/components/ManualInput.tsx",
                        lineNumber: 115,
                        columnNumber: 11
                    }, this),
                    " Cancel Scan"
                ]
            }, void 0, true, {
                fileName: "[project]/components/ManualInput.tsx",
                lineNumber: 114,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScanButton, {
                onClick: onScan,
                disabled: disabled,
                $disabled: disabled,
                children: "Start Scan"
            }, void 0, false, {
                fileName: "[project]/components/ManualInput.tsx",
                lineNumber: 118,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(ManualInput, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c4 = ManualInput;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "Textarea");
__turbopack_context__.k.register(_c1, "Counter");
__turbopack_context__.k.register(_c2, "ScanButton");
__turbopack_context__.k.register(_c3, "CancelButton");
__turbopack_context__.k.register(_c4, "ManualInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/urlValidation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// URL validation helpers shared across the app.
//
// Uses the URL constructor as the source of truth — same engine browsers use.
// Only http:// and https:// are accepted; other schemes (ftp, data, etc.) are rejected.
/**
 * Returns true if the string is a well-formed http/https URL.
 * Handles: empty input, whitespace-only, missing protocol, malformed hosts.
 */ __turbopack_context__.s([
    "getBaseUrlForSitemapCrawl",
    ()=>getBaseUrlForSitemapCrawl,
    "isValidUrl",
    ()=>isValidUrl,
    "normalizeUrlString",
    ()=>normalizeUrlString,
    "urlValidationHint",
    ()=>urlValidationHint
]);
function isValidUrl(value) {
    const trimmed = value.trim();
    if (!trimmed) return false;
    try {
        const u = new URL(trimmed);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch  {
        return false;
    }
}
function normalizeUrlString(value) {
    const trimmed = value.trim();
    try {
        const u = new URL(trimmed);
        const path = u.pathname.replace(/\/$/, "") || "/";
        return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}${path}${u.search}`;
    } catch  {
        return trimmed;
    }
}
function urlValidationHint(value) {
    const trimmed = value.trim();
    if (!trimmed) return null; // empty — no hint, just keep button disabled silently
    try {
        const u = new URL(trimmed);
        if (u.protocol !== "http:" && u.protocol !== "https:") {
            return "Only http:// and https:// URLs are supported.";
        }
        return null;
    } catch  {
        // Likely missing protocol
        if (!trimmed.startsWith("http")) {
            return "Add a protocol — e.g. https://example.com";
        }
        return "That doesn't look like a valid URL.";
    }
}
function getBaseUrlForSitemapCrawl(value) {
    const trimmed = value.trim();
    try {
        const u = new URL(trimmed);
        if (u.protocol !== "http:" && u.protocol !== "https:") return null;
        return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}/`;
    } catch  {
        return null;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SitemapInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SitemapInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/urlValidation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const Row = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "SitemapInput__Row",
    componentId: "sc-26eae054-0"
})`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 4px;

  @media (min-width: 540px) {
    flex-direction: row;
  }
`;
_c = Row;
const UrlInput = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].input.withConfig({
    displayName: "SitemapInput__UrlInput",
    componentId: "sc-26eae054-1"
})`
  flex: 1;
  width: 100%;
  padding: 0.6rem 0.9rem;
  font-size: 15px;
  border: 1px solid ${(p)=>p.$invalid ? p.$invalidBorder : p.$border};
  border-radius: 8px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$text};
  font-family: inherit;
  outline: none;
  transition: border-color 0.15s, opacity 0.15s;

  &:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }
`;
_c1 = UrlInput;
const CrawlButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "SitemapInput__CrawlButton",
    componentId: "sc-26eae054-2"
})`
  padding: 0.6rem 1.4rem;
  font-size: 15px;
  font-weight: 600;
  background: ${(p)=>p.$disabled ? "#9ca3af" : "#2563eb"};
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  white-space: nowrap;
  width: 100%;
  font-family: inherit;
  opacity: ${(p)=>p.$disabled ? 0.65 : 1};
  transition: background 0.15s, opacity 0.15s, transform 0.1s;

  &:not(:disabled):hover {
    background: #1d4ed8;
  }

  &:not(:disabled):active {
    transform: scale(0.97);
  }

  @media (min-width: 540px) {
    width: auto;
  }
`;
_c2 = CrawlButton;
const CancelButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "SitemapInput__CancelButton",
    componentId: "sc-26eae054-3"
})`
  padding: 0.6rem 1.1rem;
  font-size: 14px;
  font-weight: 600;
  background: transparent;
  color: #b91c1c;
  border: 1px solid #b91c1c;
  border-radius: 8px;
  cursor: pointer;
  white-space: nowrap;
  width: 100%;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: background 0.15s, transform 0.1s;

  &:hover {
    background: #fee2e2;
  }

  &:active {
    transform: scale(0.97);
  }

  @media (min-width: 540px) {
    width: auto;
  }
`;
_c3 = CancelButton;
const ValidationHint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "SitemapInput__ValidationHint",
    componentId: "sc-26eae054-4"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  margin: 0 0 4px;
  min-height: 16px;
`;
_c4 = ValidationHint;
const fadeIn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyframes"]`
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;
const InfoCallout = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "SitemapInput__InfoCallout",
    componentId: "sc-26eae054-5"
})`
  display: flex;
  align-items: flex-start;
  gap: 7px;
  padding: 7px 11px;
  margin: 0 0 10px;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 7px;
  background: ${(p)=>p.$bg};
  animation: ${fadeIn} 0.18s ease;
`;
_c5 = InfoCallout;
const InfoIcon = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "SitemapInput__InfoIcon",
    componentId: "sc-26eae054-6"
})`
  flex-shrink: 0;
  color: ${(p)=>p.$color};
  margin-top: 1px;
  display: flex;
`;
_c6 = InfoIcon;
const InfoText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "SitemapInput__InfoText",
    componentId: "sc-26eae054-7"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  line-height: 1.5;
`;
_c7 = InfoText;
const Hint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "SitemapInput__Hint",
    componentId: "sc-26eae054-8"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  margin-top: 0;
  margin-bottom: 1.25rem;
`;
_c8 = Hint;
function SitemapInput({ value, onChange, onScan, onCancel, loading, isScanning, onInputChange }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const valid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidUrl"])(value);
    const disabled = loading || isScanning || !valid;
    const hint = value.trim() ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlValidationHint"])(value) : null;
    const baseUrl = valid ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBaseUrlForSitemapCrawl"])(value) : null;
    const hasPath = baseUrl !== null && value.trim().replace(/\/$/, "") !== baseUrl.replace(/\/$/, "");
    function handleChange(e) {
        onChange(e.target.value);
        onInputChange?.();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlInput, {
                        type: "text",
                        placeholder: "https://example.com",
                        value: value,
                        onChange: handleChange,
                        onKeyDown: (e)=>e.key === "Enter" && !disabled && onScan(),
                        disabled: loading || isScanning,
                        $border: t.border,
                        $bg: t.bg,
                        $text: t.text,
                        $invalid: !!hint,
                        $invalidBorder: t.failText
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CancelButton, {
                        onClick: onCancel,
                        type: "button",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseLine"], {
                                size: 15
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapInput.tsx",
                                lineNumber: 211,
                                columnNumber: 13
                            }, this),
                            " Cancel"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 210,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CrawlButton, {
                        onClick: onScan,
                        disabled: disabled,
                        $disabled: disabled,
                        children: "Crawl Sitemap"
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 214,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapInput.tsx",
                lineNumber: 194,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ValidationHint, {
                $color: t.failText,
                children: hint ?? ""
            }, void 0, false, {
                fileName: "[project]/components/SitemapInput.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this),
            hasPath && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InfoCallout, {
                $bg: t.infoBg,
                $border: t.infoBorder,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InfoIcon, {
                        $color: t.infoText,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiInformationLine"], {
                            size: 14
                        }, void 0, false, {
                            fileName: "[project]/components/SitemapInput.tsx",
                            lineNumber: 225,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 224,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InfoText, {
                        $color: t.infoText,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Sitemap crawl uses the site root:"
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapInput.tsx",
                                lineNumber: 228,
                                columnNumber: 13
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontWeight: 500
                                },
                                children: baseUrl
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapInput.tsx",
                                lineNumber: 229,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 227,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapInput.tsx",
                lineNumber: 223,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Hint, {
                $color: t.textFaint,
                children: [
                    "PurrScope tries ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                        children: "/sitemap.xml"
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 235,
                        columnNumber: 25
                    }, this),
                    " then",
                    " ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                        children: "/sitemap_index.xml"
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapInput.tsx",
                        lineNumber: 236,
                        columnNumber: 9
                    }, this),
                    ". Once discovered, you can review the filtered pages before scanning."
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapInput.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(SitemapInput, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c9 = SitemapInput;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
__turbopack_context__.k.register(_c, "Row");
__turbopack_context__.k.register(_c1, "UrlInput");
__turbopack_context__.k.register(_c2, "CrawlButton");
__turbopack_context__.k.register(_c3, "CancelButton");
__turbopack_context__.k.register(_c4, "ValidationHint");
__turbopack_context__.k.register(_c5, "InfoCallout");
__turbopack_context__.k.register(_c6, "InfoIcon");
__turbopack_context__.k.register(_c7, "InfoText");
__turbopack_context__.k.register(_c8, "Hint");
__turbopack_context__.k.register(_c9, "SitemapInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/FilterDebug.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FilterDebug
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const PREVIEW_LIMIT = 20;
// ── Styled primitives ─────────────────────────────────────────────────────────
const Wrapper = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__Wrapper",
    componentId: "sc-a11c7392-0"
})`
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  overflow: hidden;
  margin-top: 12px;
`;
_c = Wrapper;
const StatsGrid = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__StatsGrid",
    componentId: "sc-a11c7392-1"
})`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  background: ${(p)=>p.$gap};
`;
_c1 = StatsGrid;
const StatCell = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__StatCell",
    componentId: "sc-a11c7392-2"
})`
  background: ${(p)=>p.$bg};
  padding: 10px 14px;
  text-align: center;
`;
_c2 = StatCell;
const StatValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__StatValue",
    componentId: "sc-a11c7392-3"
})`
  font-size: 20px;
  font-weight: 700;
  color: ${(p)=>p.$color};
`;
_c3 = StatValue;
const StatLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__StatLabel",
    componentId: "sc-a11c7392-4"
})`
  font-size: 11px;
  color: ${(p)=>p.$color};
  text-transform: uppercase;
  letter-spacing: 0.05em;
`;
_c4 = StatLabel;
const SectionWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__SectionWrap",
    componentId: "sc-a11c7392-5"
})`
  border-top: 1px solid ${(p)=>p.$border};
`;
_c5 = SectionWrap;
const SectionToggle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "FilterDebug__SectionToggle",
    componentId: "sc-a11c7392-6"
})`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 16px;
  background: ${(p)=>p.$bg};
  border: none;
  cursor: pointer;
  font-weight: 600;
  font-size: 13px;
  color: ${(p)=>p.$color};
  font-family: inherit;
`;
_c6 = SectionToggle;
const SectionChevron = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "FilterDebug__SectionChevron",
    componentId: "sc-a11c7392-7"
})`
  font-size: 11px;
  color: ${(p)=>p.$color};
`;
_c7 = SectionChevron;
const SectionBody = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__SectionBody",
    componentId: "sc-a11c7392-8"
})`
  padding: 10px 16px 14px;
  background: ${(p)=>p.$bg};
`;
_c8 = SectionBody;
const UrlOl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ol.withConfig({
    displayName: "FilterDebug__UrlOl",
    componentId: "sc-a11c7392-9"
})`
  margin: 0;
  padding: 0 0 0 1.4rem;
  line-height: 1.9;
`;
_c9 = UrlOl;
const UrlLink = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].a.withConfig({
    displayName: "FilterDebug__UrlLink",
    componentId: "sc-a11c7392-10"
})`
  color: ${(p)=>p.$color};
  word-break: break-all;
  text-decoration: none;
  font-size: 13px;
`;
_c10 = UrlLink;
const More = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__More",
    componentId: "sc-a11c7392-11"
})`
  color: ${(p)=>p.$color};
  font-size: 12px;
  margin-top: 6px;
  font-style: italic;
`;
_c11 = More;
const PatternCode = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].code.withConfig({
    displayName: "FilterDebug__PatternCode",
    componentId: "sc-a11c7392-12"
})`
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  font-family: inherit;
`;
_c12 = PatternCode;
const TagsWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "FilterDebug__TagsWrap",
    componentId: "sc-a11c7392-13"
})`
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
`;
_c13 = TagsWrap;
// ── Sub-components ────────────────────────────────────────────────────────────
function Section({ title, children, defaultOpen = false }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultOpen);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionWrap, {
        $border: t.border,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionToggle, {
                onClick: ()=>setOpen((v)=>!v),
                $bg: t.bgSubtle,
                $color: t.text,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionChevron, {
                        $color: t.textFaint,
                        children: open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowUpSLine"], {
                            size: 16
                        }, void 0, false, {
                            fileName: "[project]/components/FilterDebug.tsx",
                            lineNumber: 125,
                            columnNumber: 19
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowDownSLine"], {
                            size: 16
                        }, void 0, false, {
                            fileName: "[project]/components/FilterDebug.tsx",
                            lineNumber: 125,
                            columnNumber: 50
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionBody, {
                $bg: t.bg,
                children: children
            }, void 0, false, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 128,
                columnNumber: 16
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/FilterDebug.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(Section, "xkxqEcuNQx/vsF2/6or6OQWvPz4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c14 = Section;
function UrlList({ urls }) {
    _s1();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlOl, {
        children: urls.map((u)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlLink, {
                    href: u,
                    target: "_blank",
                    rel: "noreferrer",
                    $color: t.link,
                    children: u
                }, void 0, false, {
                    fileName: "[project]/components/FilterDebug.tsx",
                    lineNumber: 140,
                    columnNumber: 11
                }, this)
            }, u, false, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 139,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/FilterDebug.tsx",
        lineNumber: 137,
        columnNumber: 5
    }, this);
}
_s1(UrlList, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c15 = UrlList;
function FilterDebug({ filter }) {
    _s2();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrapper, {
        $border: t.border,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatsGrid, {
                $gap: t.border,
                children: [
                    {
                        label: "Discovered",
                        value: filter.totalDiscovered
                    },
                    {
                        label: "After Filter",
                        value: filter.totalAfterFiltering
                    },
                    {
                        label: "Excluded",
                        value: filter.excludedUrls.length
                    }
                ].map(({ label, value })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCell, {
                        $bg: t.bgSubtle,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatValue, {
                                $color: t.text,
                                children: value
                            }, void 0, false, {
                                fileName: "[project]/components/FilterDebug.tsx",
                                lineNumber: 162,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatLabel, {
                                $color: t.textMuted,
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/components/FilterDebug.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this)
                        ]
                    }, label, true, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 161,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: `Included URLs — first ${Math.min(PREVIEW_LIMIT, filter.includedUrls.length)} of ${filter.totalAfterFiltering}`,
                defaultOpen: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlList, {
                        urls: filter.includedUrls.slice(0, PREVIEW_LIMIT)
                    }, void 0, false, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 169,
                        columnNumber: 9
                    }, this),
                    filter.includedUrls.length > PREVIEW_LIMIT && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(More, {
                        $color: t.textFaint,
                        children: [
                            "… and ",
                            filter.includedUrls.length - PREVIEW_LIMIT,
                            " more"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 168,
                columnNumber: 7
            }, this),
            filter.excludedUrls.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: `Excluded URLs — first ${Math.min(PREVIEW_LIMIT, filter.excludedUrls.length)} of ${filter.excludedUrls.length}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlList, {
                        urls: filter.excludedUrls.slice(0, PREVIEW_LIMIT)
                    }, void 0, false, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 177,
                        columnNumber: 11
                    }, this),
                    filter.excludedUrls.length > PREVIEW_LIMIT && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(More, {
                        $color: t.textFaint,
                        children: [
                            "… and ",
                            filter.excludedUrls.length - PREVIEW_LIMIT,
                            " more"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/FilterDebug.tsx",
                        lineNumber: 179,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 176,
                columnNumber: 9
            }, this),
            filter.excludedPatterns.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: `Active Exclude Patterns (${filter.excludedPatterns.length})`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TagsWrap, {
                    children: filter.excludedPatterns.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PatternCode, {
                            $bg: t.bgMuted,
                            $color: t.text,
                            children: p
                        }, p, false, {
                            fileName: "[project]/components/FilterDebug.tsx",
                            lineNumber: 188,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/FilterDebug.tsx",
                    lineNumber: 186,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/FilterDebug.tsx",
                lineNumber: 185,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/FilterDebug.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
_s2(FilterDebug, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c16 = FilterDebug;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16;
__turbopack_context__.k.register(_c, "Wrapper");
__turbopack_context__.k.register(_c1, "StatsGrid");
__turbopack_context__.k.register(_c2, "StatCell");
__turbopack_context__.k.register(_c3, "StatValue");
__turbopack_context__.k.register(_c4, "StatLabel");
__turbopack_context__.k.register(_c5, "SectionWrap");
__turbopack_context__.k.register(_c6, "SectionToggle");
__turbopack_context__.k.register(_c7, "SectionChevron");
__turbopack_context__.k.register(_c8, "SectionBody");
__turbopack_context__.k.register(_c9, "UrlOl");
__turbopack_context__.k.register(_c10, "UrlLink");
__turbopack_context__.k.register(_c11, "More");
__turbopack_context__.k.register(_c12, "PatternCode");
__turbopack_context__.k.register(_c13, "TagsWrap");
__turbopack_context__.k.register(_c14, "Section");
__turbopack_context__.k.register(_c15, "UrlList");
__turbopack_context__.k.register(_c16, "FilterDebug");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/scan/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Shared types for the dual-pipeline scan architecture.
// Both pipelines must produce ScanResult[] (from lib/types.ts) so results
// are directly comparable. This file adds pipeline-level metadata only.
__turbopack_context__.s([
    "DEFAULT_PERFORMANCE_MODE",
    ()=>DEFAULT_PERFORMANCE_MODE,
    "IMPROVED_CONCURRENCY",
    ()=>IMPROVED_CONCURRENCY,
    "PERFORMANCE_CONFIGS",
    ()=>PERFORMANCE_CONFIGS
]);
const PERFORMANCE_CONFIGS = {
    safe: {
        concurrency: 2,
        fetchTimeoutMs: 14000,
        pwNavTimeoutMs: 22000,
        pwStabilizeMs: 900,
        delayBetweenTasksMs: 300,
        label: "Safe",
        description: "Low resource usage — best for slower PCs"
    },
    balanced: {
        concurrency: 4,
        fetchTimeoutMs: 10000,
        pwNavTimeoutMs: 18000,
        pwStabilizeMs: 600,
        delayBetweenTasksMs: 0,
        label: "Balanced",
        description: "Good mix of speed and stability (default)"
    },
    fast: {
        concurrency: 6,
        fetchTimeoutMs: 7000,
        pwNavTimeoutMs: 14000,
        pwStabilizeMs: 400,
        delayBetweenTasksMs: 0,
        label: "Fast",
        description: "Higher throughput — best for powerful PCs"
    }
};
const DEFAULT_PERFORMANCE_MODE = "balanced";
const IMPROVED_CONCURRENCY = PERFORMANCE_CONFIGS.balanced.concurrency;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/PerformanceModeSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PerformanceModeSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// PerformanceModeSelector — segmented button control for the Improved Process.
// Only affects the Improved pipeline. Previous Process is unaffected.
//
// To remove this component later:
//   1. Delete this file.
//   2. Remove performanceMode state and props from SitemapDebug and app/page.tsx.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/scan/types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const MODES = [
    "safe",
    "balanced",
    "fast"
];
// ── Styled ────────────────────────────────────────────────────────────────────
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "PerformanceModeSelector__Wrap",
    componentId: "sc-9ce71b31-0"
})` margin-top: 10px; `;
_c = Wrap;
const Label = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "PerformanceModeSelector__Label",
    componentId: "sc-9ce71b31-1"
})`
  font-size: 12px;
  font-weight: 600;
  color: ${(p)=>p.$color};
  margin-bottom: 6px;
`;
_c1 = Label;
const ButtonGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "PerformanceModeSelector__ButtonGroup",
    componentId: "sc-9ce71b31-2"
})`
  display: inline-flex;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 7px;
  overflow: hidden;
`;
_c2 = ButtonGroup;
const ModeBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "PerformanceModeSelector__ModeBtn",
    componentId: "sc-9ce71b31-3"
})`
  padding: 5px 14px;
  font-size: 12px;
  font-weight: 600;
  font-family: inherit;
  border: none;
  border-right: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$active ? p.$activeBg : p.$idleBg};
  color: ${(p)=>p.$active ? p.$activeTxt : p.$idleTxt};
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  opacity: ${(p)=>p.$disabled ? 0.55 : 1};
  transition: background 0.12s, color 0.12s;
  &:last-child { border-right: none; }
`;
_c3 = ModeBtn;
const HelperText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "PerformanceModeSelector__HelperText",
    componentId: "sc-9ce71b31-4"
})`
  font-size: 11px;
  color: ${(p)=>p.$color};
  margin-top: 5px;
`;
_c4 = HelperText;
function PerformanceModeSelector({ value, onChange, disabled = false }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const cfg = __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_CONFIGS"][value];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Label, {
                $color: t.textMuted,
                children: "Performance Mode (Improved Process only)"
            }, void 0, false, {
                fileName: "[project]/components/PerformanceModeSelector.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ButtonGroup, {
                $border: t.border,
                children: MODES.map((mode)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ModeBtn, {
                        type: "button",
                        onClick: ()=>{
                            if (!disabled) onChange(mode);
                        },
                        $active: value === mode,
                        $activeBg: t.btnActive,
                        $activeTxt: t.btnActiveTxt,
                        $idleBg: t.btnIdle,
                        $idleTxt: t.btnIdleTxt,
                        $border: t.border,
                        $disabled: disabled,
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_CONFIGS"][mode].label
                    }, mode, false, {
                        fileName: "[project]/components/PerformanceModeSelector.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/PerformanceModeSelector.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HelperText, {
                $color: t.textFaint,
                children: [
                    cfg.description,
                    " · ",
                    cfg.concurrency,
                    " worker",
                    cfg.concurrency > 1 ? "s" : ""
                ]
            }, void 0, true, {
                fileName: "[project]/components/PerformanceModeSelector.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/PerformanceModeSelector.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
_s(PerformanceModeSelector, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c5 = PerformanceModeSelector;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "Label");
__turbopack_context__.k.register(_c2, "ButtonGroup");
__turbopack_context__.k.register(_c3, "ModeBtn");
__turbopack_context__.k.register(_c4, "HelperText");
__turbopack_context__.k.register(_c5, "PerformanceModeSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SitemapDebug.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SitemapDebug
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// SitemapDebug — shown after sitemap discovery, BEFORE scanning.
// Displays:
//   - Crawl summary: sitemaps processed, URLs discovered, URLs after filtering, URLs to scan
//   - Configurable scan limit input (optional — leave blank to scan all)
//   - FilterDebug panel (scope stats, included/excluded URLs, mappings)
//   - Collapsible list of processed sitemap files
//   - "Scan N Pages" button to proceed
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FilterDebug$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/FilterDebug.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PerformanceModeSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PerformanceModeSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function SitemapDebug({ crawl, filter, onScan, onScanImproved, onCancel, scanning, scanLimit, onScanLimitChange, maxScanLimit, pipelineUsed, performanceMode, onPerformanceModeChange, benchmarkRunMode, onBenchmarkRunModeChange, onResetBenchmark, hasBenchmarkData }) {
    _s();
    const [sitemapsOpen, setSitemapsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    // How many pages will actually be scanned given the current limit
    const willScan = scanLimit !== "" && scanLimit > 0 ? Math.min(scanLimit, filter.totalAfterFiltering) : filter.totalAfterFiltering;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            border: `1px solid ${t.infoBorder}`,
            borderRadius: 10,
            marginBottom: "1.5rem",
            overflow: "hidden",
            fontSize: 13,
            background: t.bg,
            boxShadow: "0 1px 4px rgba(0,0,0,0.08)"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: "12px 16px",
                    background: t.infoBg,
                    borderBottom: `1px solid ${t.infoBorder}`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            gap: 10,
                            marginBottom: 10
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontWeight: 700,
                                    fontSize: 14,
                                    color: t.infoText
                                },
                                children: [
                                    "Discovery Results",
                                    pipelineUsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontWeight: 400,
                                            fontSize: 12,
                                            color: t.textMuted,
                                            marginLeft: 10
                                        },
                                        children: [
                                            "scanned via ",
                                            pipelineUsed === "previous" ? "standard pipeline" : "optimized pipeline"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 67,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this),
                            scanning ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onCancel,
                                style: {
                                    padding: "6px 14px",
                                    fontSize: 13,
                                    fontWeight: 600,
                                    background: "transparent",
                                    color: t.failText,
                                    border: `1px solid ${t.failText}`,
                                    borderRadius: 6,
                                    cursor: "pointer",
                                    whiteSpace: "nowrap",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 5,
                                    fontFamily: "inherit",
                                    alignSelf: "flex-start"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseLine"], {
                                        size: 14
                                    }, void 0, false, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 84,
                                        columnNumber: 15
                                    }, this),
                                    " Cancel Scan"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 73,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "flex-start",
                                    gap: 4
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onScanImproved,
                                        disabled: willScan === 0,
                                        title: "Scan pages using the improved concurrent pipeline",
                                        style: {
                                            padding: "8px 18px",
                                            fontSize: 13,
                                            fontWeight: 600,
                                            background: willScan === 0 ? t.textFaint : t.btnActive,
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: 6,
                                            cursor: willScan === 0 ? "not-allowed" : "pointer",
                                            whiteSpace: "nowrap",
                                            opacity: willScan === 0 ? 0.65 : 1,
                                            fontFamily: "inherit",
                                            width: "100%"
                                        },
                                        children: [
                                            "Start Scan ",
                                            willScan > 0 ? `— ${willScan} Pages` : ""
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 88,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PerformanceModeSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        value: performanceMode,
                                        onChange: onPerformanceModeChange,
                                        disabled: scanning
                                    }, void 0, false, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 105,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: "flex",
                                            flexWrap: "wrap",
                                            alignItems: "center",
                                            gap: 8,
                                            marginTop: 6
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontSize: 11,
                                                    fontWeight: 600,
                                                    color: t.textMuted,
                                                    whiteSpace: "nowrap"
                                                },
                                                children: "Run mode:"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SitemapDebug.tsx",
                                                lineNumber: 112,
                                                columnNumber: 17
                                            }, this),
                                            [
                                                "cold",
                                                "warm"
                                            ].map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>{
                                                        if (!scanning) onBenchmarkRunModeChange(m);
                                                    },
                                                    style: {
                                                        padding: "3px 10px",
                                                        fontSize: 11,
                                                        fontWeight: 600,
                                                        borderRadius: 5,
                                                        border: `1px solid ${t.border}`,
                                                        background: benchmarkRunMode === m ? t.btnActive : t.btnIdle,
                                                        color: benchmarkRunMode === m ? t.btnActiveTxt : t.btnIdleTxt,
                                                        cursor: scanning ? "not-allowed" : "pointer",
                                                        opacity: scanning ? 0.55 : 1,
                                                        fontFamily: "inherit"
                                                    },
                                                    children: m === "cold" ? "Cold" : "Warm"
                                                }, m, false, {
                                                    fileName: "[project]/components/SitemapDebug.tsx",
                                                    lineNumber: 116,
                                                    columnNumber: 19
                                                }, this)),
                                            hasBenchmarkData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>{
                                                    if (!scanning) onResetBenchmark();
                                                },
                                                disabled: scanning,
                                                style: {
                                                    padding: "3px 10px",
                                                    fontSize: 11,
                                                    fontWeight: 600,
                                                    borderRadius: 5,
                                                    border: `1px solid ${t.failText}`,
                                                    background: "transparent",
                                                    color: t.failText,
                                                    cursor: scanning ? "not-allowed" : "pointer",
                                                    opacity: scanning ? 0.55 : 1,
                                                    fontFamily: "inherit"
                                                },
                                                children: "Reset Benchmark"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SitemapDebug.tsx",
                                                lineNumber: 134,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(3, 1fr)",
                            gap: 8,
                            marginBottom: 12
                        },
                        children: [
                            {
                                label: "URLs Discovered",
                                value: crawl.pageCount,
                                color: t.infoText
                            },
                            {
                                label: "Pages Selected for Scan",
                                value: filter.totalAfterFiltering,
                                color: t.passText
                            },
                            {
                                label: "Ready to Scan",
                                value: willScan,
                                color: t.link
                            }
                        ].map(({ label, value, color })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    background: t.bg,
                                    borderRadius: 6,
                                    padding: "8px 12px",
                                    border: `1px solid ${t.infoBorder}`,
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: 22,
                                            fontWeight: 700,
                                            color
                                        },
                                        children: value
                                    }, void 0, false, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 169,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: 11,
                                            color: t.textMuted,
                                            textTransform: "uppercase",
                                            letterSpacing: "0.04em"
                                        },
                                        children: label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SitemapDebug.tsx",
                                        lineNumber: 170,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, label, true, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 165,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            flexWrap: "wrap",
                            alignItems: "center",
                            gap: 10
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                style: {
                                    fontSize: 13,
                                    fontWeight: 600,
                                    color: t.text,
                                    whiteSpace: "nowrap"
                                },
                                children: "Scan limit:"
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 179,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                min: 1,
                                max: maxScanLimit,
                                placeholder: `All ${filter.totalAfterFiltering} pages`,
                                value: scanLimit,
                                disabled: scanning || maxScanLimit === 0,
                                onChange: (e)=>{
                                    const v = e.target.value;
                                    if (v === "") {
                                        onScanLimitChange("");
                                        return;
                                    }
                                    const parsed = parseInt(v, 10);
                                    if (isNaN(parsed)) return;
                                    onScanLimitChange(Math.min(Math.max(1, parsed), maxScanLimit));
                                },
                                style: {
                                    width: 140,
                                    padding: "4px 8px",
                                    fontSize: 13,
                                    border: `1px solid ${t.infoBorder}`,
                                    borderRadius: 6,
                                    background: t.bg,
                                    color: t.text,
                                    opacity: scanning || maxScanLimit === 0 ? 0.55 : 1,
                                    cursor: scanning || maxScanLimit === 0 ? "not-allowed" : "text"
                                }
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 182,
                                columnNumber: 11
                            }, this),
                            scanLimit !== "" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>onScanLimitChange(""),
                                disabled: scanning,
                                style: {
                                    fontSize: 12,
                                    color: t.textMuted,
                                    background: "none",
                                    border: "none",
                                    cursor: scanning ? "not-allowed" : "pointer",
                                    textDecoration: "underline",
                                    opacity: scanning ? 0.45 : 1,
                                    fontFamily: "inherit"
                                },
                                children: "clear (scan all)"
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 205,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontSize: 12,
                                    color: t.textFaint
                                },
                                children: maxScanLimit === 0 ? "No pages available to scan." : `Leave blank to scan all ${filter.totalAfterFiltering} selected pages.`
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 219,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 178,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapDebug.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: "12px 16px",
                    borderBottom: `1px solid ${t.border}`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            fontWeight: 600,
                            color: t.text,
                            marginBottom: 4
                        },
                        children: "Filter Results"
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 229,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FilterDebug$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        filter: filter
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 230,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapDebug.tsx",
                lineNumber: 228,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSitemapsOpen((v)=>!v),
                        style: {
                            width: "100%",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            padding: "9px 16px",
                            background: t.bgSubtle,
                            border: "none",
                            cursor: "pointer",
                            fontWeight: 600,
                            color: t.text,
                            borderBottom: sitemapsOpen ? `1px solid ${t.border}` : "none",
                            fontFamily: "inherit"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "Sitemap files processed (",
                                    crawl.sitemapCount,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 246,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontSize: 11,
                                    color: t.textFaint
                                },
                                children: sitemapsOpen ? "▲ hide" : "▼ show"
                            }, void 0, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 247,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    sitemapsOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        style: {
                            margin: 0,
                            padding: "10px 16px 10px 2.2rem",
                            lineHeight: 1.9,
                            background: t.bg
                        },
                        children: crawl.sitemapUrls.map((u)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: u,
                                    target: "_blank",
                                    rel: "noreferrer",
                                    style: {
                                        color: t.link,
                                        wordBreak: "break-all",
                                        textDecoration: "none"
                                    },
                                    children: u
                                }, void 0, false, {
                                    fileName: "[project]/components/SitemapDebug.tsx",
                                    lineNumber: 256,
                                    columnNumber: 17
                                }, this)
                            }, u, false, {
                                fileName: "[project]/components/SitemapDebug.tsx",
                                lineNumber: 255,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SitemapDebug.tsx",
                        lineNumber: 253,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SitemapDebug.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SitemapDebug.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
_s(SitemapDebug, "8JlVjzB9aNF1HoX7qH50Duv9IVA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = SitemapDebug;
var _c;
__turbopack_context__.k.register(_c, "SitemapDebug");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ExclusionDropdown.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExclusionDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// ── Styled ────────────────────────────────────────────────────────────────────
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ExclusionDropdown__Wrap",
    componentId: "sc-8bbbcdc6-0"
})` position: relative; `;
_c = Wrap;
const FieldLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].label.withConfig({
    displayName: "ExclusionDropdown__FieldLabel",
    componentId: "sc-8bbbcdc6-1"
})`
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: ${(p)=>p.$color};
  margin-bottom: 6px;
`;
_c1 = FieldLabel;
const Trigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ExclusionDropdown__Trigger",
    componentId: "sc-8bbbcdc6-2"
})`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.55rem 0.8rem;
  font-size: 14px;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$text};
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  opacity: ${(p)=>p.$disabled ? 0.55 : 1};
  font-family: inherit;
  text-align: left;
  gap: 8px;
`;
_c2 = Trigger;
const TriggerText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ExclusionDropdown__TriggerText",
    componentId: "sc-8bbbcdc6-3"
})`
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: ${(p)=>p.$muted ? p.$mutedColor : p.$color};
`;
_c3 = TriggerText;
const Popover = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ExclusionDropdown__Popover",
    componentId: "sc-8bbbcdc6-4"
})`
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  z-index: 50;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  background: ${(p)=>p.$bg};
  box-shadow: 0 4px 12px rgba(0,0,0,0.12);
  overflow: hidden;
`;
_c4 = Popover;
const OptionRow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ExclusionDropdown__OptionRow",
    componentId: "sc-8bbbcdc6-5"
})`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  font-size: 13px;
  font-family: inherit;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  border: none;
  border-bottom: 1px solid ${(p)=>p.$border};
  cursor: pointer;
  text-align: left;
  &:last-child { border-bottom: none; }
  &:hover { background: ${(p)=>p.$hoverBg}; }
`;
_c5 = OptionRow;
const CheckWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ExclusionDropdown__CheckWrap",
    componentId: "sc-8bbbcdc6-6"
})`
  flex-shrink: 0;
  width: 16px;
  color: ${(p)=>p.$color};
  opacity: ${(p)=>p.$visible ? 1 : 0};
`;
_c6 = CheckWrap;
const HelperText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "ExclusionDropdown__HelperText",
    componentId: "sc-8bbbcdc6-7"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  margin: 4px 0 0;
`;
_c7 = HelperText;
// ── Helpers ───────────────────────────────────────────────────────────────────
function triggerLabel(groups, selected) {
    if (selected.length === 0) return {
        text: "None — include all dynamic pages",
        muted: true
    };
    const selectedGroups = groups.filter((g)=>selected.includes(g.sitemapUrl));
    if (selectedGroups.length <= 2) return {
        text: selectedGroups.map((g)=>g.label).join(", "),
        muted: false
    };
    return {
        text: `${selectedGroups.length} selected`,
        muted: false
    };
}
function ExclusionDropdown({ groups, selected, onChange, disabled = false }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const wrapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Close on outside click
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ExclusionDropdown.useEffect": ()=>{
            if (!open) return;
            function handleMouseDown(e) {
                if (wrapRef.current && !wrapRef.current.contains(e.target)) {
                    setOpen(false);
                }
            }
            document.addEventListener("mousedown", handleMouseDown);
            return ({
                "ExclusionDropdown.useEffect": ()=>document.removeEventListener("mousedown", handleMouseDown)
            })["ExclusionDropdown.useEffect"];
        }
    }["ExclusionDropdown.useEffect"], [
        open
    ]);
    function toggleGroup(sitemapUrl) {
        if (selected.includes(sitemapUrl)) {
            onChange(selected.filter((u)=>u !== sitemapUrl));
        } else {
            onChange([
                ...selected,
                sitemapUrl
            ]);
        }
    }
    const { text, muted } = triggerLabel(groups, selected);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        ref: wrapRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FieldLabel, {
                $color: t.text,
                children: "Exclude Dynamic Page Types"
            }, void 0, false, {
                fileName: "[project]/components/ExclusionDropdown.tsx",
                lineNumber: 139,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Trigger, {
                type: "button",
                onClick: ()=>{
                    if (!disabled) setOpen((o)=>!o);
                },
                disabled: disabled,
                $disabled: disabled,
                $border: t.border,
                $bg: t.bgSubtle,
                $text: t.text,
                "aria-haspopup": "listbox",
                "aria-expanded": open,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TriggerText, {
                        $muted: muted,
                        $color: t.text,
                        $mutedColor: t.textFaint,
                        children: text
                    }, void 0, false, {
                        fileName: "[project]/components/ExclusionDropdown.tsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this),
                    open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowUpSLine"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/components/ExclusionDropdown.tsx",
                        lineNumber: 154,
                        columnNumber: 17
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowDownSLine"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/components/ExclusionDropdown.tsx",
                        lineNumber: 154,
                        columnNumber: 48
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ExclusionDropdown.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Popover, {
                $border: t.border,
                $bg: t.bg,
                role: "listbox",
                "aria-multiselectable": "true",
                children: groups.map((g)=>{
                    const isSelected = selected.includes(g.sitemapUrl);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OptionRow, {
                        type: "button",
                        role: "option",
                        "aria-selected": isSelected,
                        onClick: ()=>toggleGroup(g.sitemapUrl),
                        $border: t.border,
                        $bg: t.bg,
                        $hoverBg: t.bgSubtle,
                        $color: t.text,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CheckWrap, {
                                $visible: isSelected,
                                $color: t.passText,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCheckLine"], {
                                    size: 14
                                }, void 0, false, {
                                    fileName: "[project]/components/ExclusionDropdown.tsx",
                                    lineNumber: 174,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/ExclusionDropdown.tsx",
                                lineNumber: 173,
                                columnNumber: 17
                            }, this),
                            g.label
                        ]
                    }, g.sitemapUrl, true, {
                        fileName: "[project]/components/ExclusionDropdown.tsx",
                        lineNumber: 162,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/ExclusionDropdown.tsx",
                lineNumber: 158,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HelperText, {
                $color: t.textFaint,
                children: "Choose dynamic sitemap groups to exclude from scan."
            }, void 0, false, {
                fileName: "[project]/components/ExclusionDropdown.tsx",
                lineNumber: 183,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ExclusionDropdown.tsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
_s(ExclusionDropdown, "YYugWu/3ZClfEm4jIRoYLNLafOw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c8 = ExclusionDropdown;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "FieldLabel");
__turbopack_context__.k.register(_c2, "Trigger");
__turbopack_context__.k.register(_c3, "TriggerText");
__turbopack_context__.k.register(_c4, "Popover");
__turbopack_context__.k.register(_c5, "OptionRow");
__turbopack_context__.k.register(_c6, "CheckWrap");
__turbopack_context__.k.register(_c7, "HelperText");
__turbopack_context__.k.register(_c8, "ExclusionDropdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ScopeSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScopeSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ExclusionDropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ExclusionDropdown.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const SCOPE_OPTIONS = [
    {
        value: "all",
        label: "All Pages",
        description: "Scan every URL discovered in the sitemap (sitemap-static.xml + all -dpages.xml files)."
    },
    {
        value: "static",
        label: "Static Pages Only",
        description: "Include only URLs from sitemap-static.xml."
    },
    {
        value: "dynamic",
        label: "Dynamic Pages",
        description: "Include only URLs from sitemaps ending in -dpages.xml."
    }
];
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ScopeSelector__Wrap",
    componentId: "sc-5bf86bc7-0"
})` margin-bottom: 1.25rem; `;
_c = Wrap;
const Label = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].label.withConfig({
    displayName: "ScopeSelector__Label",
    componentId: "sc-5bf86bc7-1"
})`
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: ${(p)=>p.$color};
  margin-bottom: 6px;
`;
_c1 = Label;
const Select = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].select.withConfig({
    displayName: "ScopeSelector__Select",
    componentId: "sc-5bf86bc7-2"
})`
  width: 100%;
  padding: 0.55rem 0.8rem;
  font-size: 14px;
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$text};
  margin-bottom: 6px;
  font-family: inherit;
  transition: opacity 0.15s;
  &:disabled { opacity: 0.55; cursor: not-allowed; }
`;
_c2 = Select;
const Hint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "ScopeSelector__Hint",
    componentId: "sc-5bf86bc7-3"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  margin: 0 0 12px;
`;
_c3 = Hint;
const DropdownWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ScopeSelector__DropdownWrap",
    componentId: "sc-5bf86bc7-4"
})` margin-top: 4px; `;
_c4 = DropdownWrap;
function ScopeSelector({ scope, onScopeChange, disabled = false, dynamicGroups = [], selectedGroups = [], onSelectedGroupsChange }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Label, {
                $color: t.text,
                children: "Scan Scope"
            }, void 0, false, {
                fileName: "[project]/components/ScopeSelector.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Select, {
                value: scope,
                onChange: (e)=>onScopeChange(e.target.value),
                disabled: disabled,
                $border: t.border,
                $bg: t.bgSubtle,
                $text: t.text,
                children: SCOPE_OPTIONS.map((o)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: o.value,
                        children: o.label
                    }, o.value, false, {
                        fileName: "[project]/components/ScopeSelector.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/ScopeSelector.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Hint, {
                $color: t.textMuted,
                children: SCOPE_OPTIONS.find((o)=>o.value === scope)?.description
            }, void 0, false, {
                fileName: "[project]/components/ScopeSelector.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            scope === "dynamic" && dynamicGroups.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DropdownWrap, {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ExclusionDropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    groups: dynamicGroups,
                    selected: selectedGroups,
                    onChange: onSelectedGroupsChange ?? (()=>{}),
                    disabled: disabled
                }, void 0, false, {
                    fileName: "[project]/components/ScopeSelector.tsx",
                    lineNumber: 84,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ScopeSelector.tsx",
                lineNumber: 83,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ScopeSelector.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(ScopeSelector, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c5 = ScopeSelector;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "Label");
__turbopack_context__.k.register(_c2, "Select");
__turbopack_context__.k.register(_c3, "Hint");
__turbopack_context__.k.register(_c4, "DropdownWrap");
__turbopack_context__.k.register(_c5, "ScopeSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/copy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Utility for building the plain-text "Copy Results" output.
__turbopack_context__.s([
    "buildCopyText",
    ()=>buildCopyText
]);
function buildCopyText(results) {
    return results.map((r)=>{
        const path = (()=>{
            try {
                return new URL(r.url).pathname || "/";
            } catch  {
                return r.url;
            }
        })();
        if (r.error) return `❌ ${path} — Error: ${r.error}`;
        const issues = [];
        if (!r.title) {
            issues.push("Title missing");
        } else if (r.titleStatus === "Fail") {
            issues.push(`Title ${r.titleLength < 45 ? "too short" : "too long"} (${r.titleLength} chars)`);
        }
        if (!r.description) {
            issues.push("Description missing");
        } else if (r.descriptionStatus === "Fail") {
            issues.push(`Description ${r.descriptionLength < 145 ? "too short" : "too long"} (${r.descriptionLength} chars)`);
        }
        return issues.length === 0 ? `✅ ${path} — All good` : issues.map((i)=>`❌ ${path} — ${i}`).join("\n");
    }).join("\n");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/duration.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Formats a duration in milliseconds into a human-readable string.
 * - < 60s  → "1.4s"
 * - >= 60s → "1m 12s"
 * - <= 0   → "0.0s"
 */ __turbopack_context__.s([
    "executionLabel",
    ()=>executionLabel,
    "formatDuration",
    ()=>formatDuration
]);
function formatDuration(ms) {
    if (ms <= 0) return "0.0s";
    if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
    const totalSecs = Math.floor(ms / 1000);
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}m ${secs.toString().padStart(2, "0")}s`;
}
function executionLabel(status, formattedDuration, processName) {
    if (status === "completed") return `${processName} in ${formattedDuration}`;
    if (status === "failed") return `Failed after ${formattedDuration}`;
    return `Stopped after ${formattedDuration}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ResultsTable.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResultsTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$copy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/copy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$duration$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/duration.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
// ── Styled primitives ─────────────────────────────────────────────────────────
const TableWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__TableWrap",
    componentId: "sc-c64c5ab7-0"
})`
  border: 1px solid ${(p)=>p.$border};
  border-radius: 10px;
  overflow: hidden;
  background: ${(p)=>p.$bg};
  box-shadow: 0 1px 4px rgba(0,0,0,0.08);
`;
_c = TableWrap;
const Toolbar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__Toolbar",
    componentId: "sc-c64c5ab7-1"
})`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 14px;
  border-bottom: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$bg};
`;
_c1 = Toolbar;
const ToolbarLeft = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__ToolbarLeft",
    componentId: "sc-c64c5ab7-2"
})` display: flex; gap: 6px; `;
_c2 = ToolbarLeft;
const FilterBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ResultsTable__FilterBtn",
    componentId: "sc-c64c5ab7-3"
})`
  padding: 4px 12px;
  font-size: 13px;
  font-weight: 600;
  border-radius: 6px;
  border: 1px solid ${(p)=>p.$border};
  cursor: ${(p)=>p.$disabled ? "not-allowed" : "pointer"};
  opacity: ${(p)=>p.$disabled ? 0.4 : 1};
  background: ${(p)=>p.$active && !p.$disabled ? p.$activeBg : p.$idleBg};
  color: ${(p)=>p.$active && !p.$disabled ? p.$activeTxt : p.$idleTxt};
  font-family: inherit;
  transition: background 0.15s, opacity 0.15s, transform 0.1s;
  &:not(:disabled):hover { opacity: 0.85; }
  &:not(:disabled):active { transform: scale(0.97); }
`;
_c3 = FilterBtn;
const CopyBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "ResultsTable__CopyBtn",
    componentId: "sc-c64c5ab7-4"
})`
  padding: 4px 12px;
  font-size: 13px;
  font-weight: 600;
  background: ${(p)=>p.$copied ? p.$passBg : p.$idleBg};
  color: ${(p)=>p.$copied ? p.$passTxt : p.$idleTxt};
  border: 1px solid ${(p)=>p.$border};
  border-radius: 6px;
  cursor: pointer;
  font-family: inherit;
  transition: background 0.15s, opacity 0.15s, transform 0.1s;
  &:hover { opacity: 0.85; }
  &:active { transform: scale(0.97); }
`;
_c4 = CopyBtn;
const ScrollWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__ScrollWrap",
    componentId: "sc-c64c5ab7-5"
})` overflow-x: auto; `;
_c5 = ScrollWrap;
const Table = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].table.withConfig({
    displayName: "ResultsTable__Table",
    componentId: "sc-c64c5ab7-6"
})` width: 100%; border-collapse: collapse; `;
_c6 = Table;
const Th = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].th.withConfig({
    displayName: "ResultsTable__Th",
    componentId: "sc-c64c5ab7-7"
})`
  padding: 10px 14px;
  font-size: 12px;
  font-weight: 600;
  color: ${(p)=>p.$color};
  text-transform: uppercase;
  letter-spacing: 0.05em;
  background: ${(p)=>p.$bg};
  border-bottom: 1px solid ${(p)=>p.$border};
  white-space: nowrap;
  text-align: ${(p)=>p.$align ?? "left"};
`;
_c7 = Th;
const Td = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].td.withConfig({
    displayName: "ResultsTable__Td",
    componentId: "sc-c64c5ab7-8"
})`
  padding: 11px 14px;
  font-size: 13px;
  border-bottom: 1px solid ${(p)=>p.$border};
  vertical-align: middle;
  color: ${(p)=>p.$color};
  text-align: ${(p)=>p.$align ?? "left"};
`;
_c8 = Td;
const DataRow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].tr.withConfig({
    displayName: "ResultsTable__DataRow",
    componentId: "sc-c64c5ab7-9"
})`
  background: ${(p)=>p.$bg};
  cursor: pointer;
  box-shadow: ${(p)=>p.$open ? `inset 3px 0 0 ${p.$accentColor}` : "none"};
  transition: filter 0.12s;
  &:hover { filter: brightness(0.97); }
`;
_c9 = DataRow;
const ExpandCell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Td).withConfig({
    displayName: "ResultsTable__ExpandCell",
    componentId: "sc-c64c5ab7-10"
})`
  user-select: none;
  padding-right: 0;
  width: 32px;
`;
_c10 = ExpandCell;
const UrlCell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Td).withConfig({
    displayName: "ResultsTable__UrlCell",
    componentId: "sc-c64c5ab7-11"
})` max-width: 300px; word-break: break-all; `;
_c11 = UrlCell;
const UrlAnchor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].a.withConfig({
    displayName: "ResultsTable__UrlAnchor",
    componentId: "sc-c64c5ab7-12"
})`
  color: ${(p)=>p.$color};
  text-decoration: none;
`;
_c12 = UrlAnchor;
const SubLine = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__SubLine",
    componentId: "sc-c64c5ab7-13"
})`
  font-size: 11px;
  color: ${(p)=>p.$color};
  margin-top: 2px;
`;
_c13 = SubLine;
const PillSpan = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__PillSpan",
    componentId: "sc-c64c5ab7-14"
})`
  display: inline-block;
  padding: 2px 9px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
`;
_c14 = PillSpan;
const LengthSpan = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__LengthSpan",
    componentId: "sc-c64c5ab7-15"
})`
  font-weight: 600;
  color: ${(p)=>p.$color};
`;
_c15 = LengthSpan;
const MissingSpan = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__MissingSpan",
    componentId: "sc-c64c5ab7-16"
})`
  color: ${(p)=>p.$color};
`;
_c16 = MissingSpan;
const ExpandedTd = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].td.withConfig({
    displayName: "ResultsTable__ExpandedTd",
    componentId: "sc-c64c5ab7-17"
})`
  padding: 12px 18px 16px 36px;
  background: ${(p)=>p.$bg};
  border-bottom: 1px solid ${(p)=>p.$border};
  font-size: 13px;
`;
_c17 = ExpandedTd;
const ExpandedGrid = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__ExpandedGrid",
    componentId: "sc-c64c5ab7-18"
})`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px 24px;
`;
_c18 = ExpandedGrid;
const ExpandedFieldLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__ExpandedFieldLabel",
    componentId: "sc-c64c5ab7-19"
})`
  font-weight: 600;
  color: ${(p)=>p.$color};
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 4px;
`;
_c19 = ExpandedFieldLabel;
const ExpandedValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__ExpandedValue",
    componentId: "sc-c64c5ab7-20"
})`
  color: ${(p)=>p.$color};
  line-height: 1.5;
`;
_c20 = ExpandedValue;
const Footer = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "ResultsTable__Footer",
    componentId: "sc-c64c5ab7-21"
})`
  padding: 10px 14px;
  border-top: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$bg};
  font-size: 13px;
  font-weight: 600;
  color: ${(p)=>p.$color};
`;
_c21 = Footer;
const ExecutionBadge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__ExecutionBadge",
    componentId: "sc-c64c5ab7-22"
})`
  font-size: 12px;
  font-weight: 400;
  color: ${(p)=>p.$color};
  margin-left: 10px;
  opacity: 0.8;
`;
_c22 = ExecutionBadge;
const IconWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "ResultsTable__IconWrap",
    componentId: "sc-c64c5ab7-23"
})`
  display: inline-flex;
  align-items: center;
  gap: 4px;
`;
_c23 = IconWrap;
// ── Sub-components ────────────────────────────────────────────────────────────
function Pill({ status, t }) {
    const pass = status === "Pass";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PillSpan, {
        $bg: pass ? t.passBg : t.failBg,
        $color: pass ? t.passText : t.failText,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
            children: [
                pass ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCheckboxCircleFill"], {
                    size: 13
                }, void 0, false, {
                    fileName: "[project]/components/ResultsTable.tsx",
                    lineNumber: 204,
                    columnNumber: 17
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseCircleFill"], {
                    size: 13
                }, void 0, false, {
                    fileName: "[project]/components/ResultsTable.tsx",
                    lineNumber: 204,
                    columnNumber: 54
                }, this),
                pass ? "Pass" : "Fail"
            ]
        }, void 0, true, {
            fileName: "[project]/components/ResultsTable.tsx",
            lineNumber: 203,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ResultsTable.tsx",
        lineNumber: 202,
        columnNumber: 5
    }, this);
}
_c24 = Pill;
function BlockedPill({ t }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PillSpan, {
        $bg: t.bgMuted,
        $color: t.textMuted,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiProhibitedLine"], {
                    size: 13
                }, void 0, false, {
                    fileName: "[project]/components/ResultsTable.tsx",
                    lineNumber: 214,
                    columnNumber: 17
                }, this),
                " Blocked"
            ]
        }, void 0, true, {
            fileName: "[project]/components/ResultsTable.tsx",
            lineNumber: 214,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ResultsTable.tsx",
        lineNumber: 213,
        columnNumber: 5
    }, this);
}
_c25 = BlockedPill;
function ExpandedRow({ r, colSpan, t }) {
    const isBlocked = r.scanStatus === "Blocked (automation)";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedTd, {
            colSpan: colSpan,
            $bg: t.bgSubtle,
            $border: t.border,
            children: isBlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedValue, {
                $color: t.textMuted,
                style: {
                    fontStyle: "italic",
                    display: "flex",
                    alignItems: "center",
                    gap: 6
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiProhibitedLine"], {
                        size: 14
                    }, void 0, false, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 226,
                        columnNumber: 13
                    }, this),
                    " This page was blocked by bot protection or an interstitial. SEO metadata could not be extracted."
                ]
            }, void 0, true, {
                fileName: "[project]/components/ResultsTable.tsx",
                lineNumber: 225,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedGrid, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedFieldLabel, {
                                $color: t.textMuted,
                                children: "SEO Title"
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 231,
                                columnNumber: 15
                            }, this),
                            r.title ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedValue, {
                                $color: t.text,
                                children: r.title
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 233,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedValue, {
                                $color: t.textFaint,
                                style: {
                                    fontStyle: "italic"
                                },
                                children: "(missing)"
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 234,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 230,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedFieldLabel, {
                                $color: t.textMuted,
                                children: "Meta Description"
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 237,
                                columnNumber: 15
                            }, this),
                            r.description ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedValue, {
                                $color: t.text,
                                children: r.description
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 239,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedValue, {
                                $color: t.textFaint,
                                style: {
                                    fontStyle: "italic"
                                },
                                children: "(missing)"
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 240,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 236,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ResultsTable.tsx",
                lineNumber: 229,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ResultsTable.tsx",
            lineNumber: 223,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ResultsTable.tsx",
        lineNumber: 222,
        columnNumber: 5
    }, this);
}
_c26 = ExpandedRow;
function ResultsTable({ results, scanTimer }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openUrl, setOpenUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const failCount = results.filter((r)=>r.scanStatus === "Blocked (automation)" || r.titleStatus === "Fail" || r.descriptionStatus === "Fail" || r.error).length;
    // Auto-reset active filter if its count drops to zero
    const tabCounts = {
        all: results.length,
        failed: failCount
    };
    if (filter !== "all" && tabCounts[filter] === 0) {
        setFilter("all");
    }
    const visible = filter === "failed" ? results.filter((r)=>r.scanStatus === "Blocked (automation)" || r.titleStatus === "Fail" || r.descriptionStatus === "Fail" || r.error) : results;
    const allPass = failCount === 0;
    function handleCopy() {
        navigator.clipboard.writeText((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$copy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildCopyText"])(results)).then(()=>{
            setCopied(true);
            setTimeout(()=>setCopied(false), 2000);
        });
    }
    // Toggle: open clicked row, close if already open
    function toggleRow(url) {
        setOpenUrl((prev)=>prev === url ? null : url);
    }
    const toolbarBg = allPass ? t.toolbarPassBg : t.toolbarFailBg;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TableWrap, {
        $border: t.border,
        $bg: t.bg,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Toolbar, {
                $border: t.border,
                $bg: toolbarBg,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ToolbarLeft, {
                        children: [
                            "all",
                            "failed"
                        ].map((f)=>{
                            const count = tabCounts[f];
                            const isDisabled = count === 0;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FilterBtn, {
                                onClick: ()=>{
                                    if (!isDisabled) setFilter(f);
                                },
                                disabled: isDisabled,
                                $active: filter === f && !isDisabled,
                                $disabled: isDisabled,
                                $activeBg: t.btnActive,
                                $idleBg: t.btnIdle,
                                $activeTxt: t.btnActiveTxt,
                                $idleTxt: t.btnIdleTxt,
                                $border: t.border,
                                children: f === "all" ? `All (${results.length})` : `Failed (${failCount})`
                            }, f, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 297,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 292,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CopyBtn, {
                        onClick: handleCopy,
                        $copied: copied,
                        $passBg: t.passBg,
                        $idleBg: t.btnIdle,
                        $passTxt: t.passText,
                        $idleTxt: t.btnIdleTxt,
                        $border: t.border,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
                            children: [
                                copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCheckLine"], {
                                    size: 14
                                }, void 0, false, {
                                    fileName: "[project]/components/ResultsTable.tsx",
                                    lineNumber: 320,
                                    columnNumber: 23
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFileCopyLine"], {
                                    size: 14
                                }, void 0, false, {
                                    fileName: "[project]/components/ResultsTable.tsx",
                                    lineNumber: 320,
                                    columnNumber: 51
                                }, this),
                                copied ? "Copied!" : "Copy Results"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ResultsTable.tsx",
                            lineNumber: 319,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 312,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ResultsTable.tsx",
                lineNumber: 291,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollWrap, {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Table, {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        style: {
                                            width: 32
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 330,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        children: "URL"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 331,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        $align: "center",
                                        children: "Title Length"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 332,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        $align: "center",
                                        children: "Title Status"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 333,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        $align: "center",
                                        children: "Desc. Length"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 334,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                        $bg: t.headerBg,
                                        $border: t.border,
                                        $color: t.textMuted,
                                        $align: "center",
                                        children: "Desc. Status"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 335,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 329,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ResultsTable.tsx",
                            lineNumber: 328,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: [
                                visible.map((r)=>{
                                    const isBlocked = r.scanStatus === "Blocked (automation)";
                                    const rowFailed = isBlocked || r.titleStatus === "Fail" || r.descriptionStatus === "Fail" || r.error;
                                    const isOpen = openUrl === r.url;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DataRow, {
                                                $bg: rowFailed ? t.rowFail : t.rowOk,
                                                $open: isOpen,
                                                $accentColor: t.btnActive,
                                                onClick: ()=>toggleRow(r.url),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandCell, {
                                                        $border: t.border,
                                                        $color: t.textFaint,
                                                        $align: "center",
                                                        children: isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowUpSLine"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 347,
                                                            columnNumber: 33
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowDownSLine"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 347,
                                                            columnNumber: 64
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 346,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlCell, {
                                                        $border: t.border,
                                                        $color: t.text,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlAnchor, {
                                                                href: r.url,
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                $color: t.link,
                                                                onClick: (e)=>e.stopPropagation(),
                                                                children: r.url
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ResultsTable.tsx",
                                                                lineNumber: 350,
                                                                columnNumber: 23
                                                            }, this),
                                                            r.finalUrl && r.finalUrl !== r.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SubLine, {
                                                                $color: t.textMuted,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCornerDownRightLine"], {
                                                                            size: 11
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                                            lineNumber: 355,
                                                                            columnNumber: 37
                                                                        }, this),
                                                                        " redirected to",
                                                                        " ",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UrlAnchor, {
                                                                            href: r.finalUrl,
                                                                            target: "_blank",
                                                                            rel: "noreferrer",
                                                                            $color: t.textMuted,
                                                                            onClick: (e)=>e.stopPropagation(),
                                                                            children: r.finalUrl
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                                            lineNumber: 356,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/ResultsTable.tsx",
                                                                    lineNumber: 355,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ResultsTable.tsx",
                                                                lineNumber: 354,
                                                                columnNumber: 25
                                                            }, this),
                                                            r.methodUsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SubLine, {
                                                                $color: t.textFaint,
                                                                children: [
                                                                    "via ",
                                                                    r.methodUsed
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/ResultsTable.tsx",
                                                                lineNumber: 362,
                                                                columnNumber: 40
                                                            }, this),
                                                            r.attempts !== undefined && r.attempts > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SubLine, {
                                                                $color: t.warnText,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiAlertLine"], {
                                                                            size: 11
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                                            lineNumber: 364,
                                                                            columnNumber: 64
                                                                        }, this),
                                                                        " needed ",
                                                                        r.attempts,
                                                                        " attempts"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/ResultsTable.tsx",
                                                                    lineNumber: 364,
                                                                    columnNumber: 54
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ResultsTable.tsx",
                                                                lineNumber: 364,
                                                                columnNumber: 25
                                                            }, this),
                                                            r.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SubLine, {
                                                                $color: t.failText,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiAlertLine"], {
                                                                            size: 11
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                                            lineNumber: 366,
                                                                            columnNumber: 74
                                                                        }, this),
                                                                        " ",
                                                                        r.error
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/ResultsTable.tsx",
                                                                    lineNumber: 366,
                                                                    columnNumber: 64
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ResultsTable.tsx",
                                                                lineNumber: 366,
                                                                columnNumber: 35
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 349,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                                        $border: t.border,
                                                        $color: t.text,
                                                        $align: "center",
                                                        children: isBlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MissingSpan, {
                                                            $color: t.textFaint,
                                                            children: "—"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 370,
                                                            columnNumber: 36
                                                        }, this) : r.title ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LengthSpan, {
                                                            $color: r.titleStatus === "Pass" ? t.passText : t.failText,
                                                            children: [
                                                                r.titleLength,
                                                                " chars"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 372,
                                                            columnNumber: 29
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MissingSpan, {
                                                            $color: t.textFaint,
                                                            children: "(missing)"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 373,
                                                            columnNumber: 29
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 369,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                                        $border: t.border,
                                                        $color: t.text,
                                                        $align: "center",
                                                        children: isBlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BlockedPill, {
                                                            t: t
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 376,
                                                            columnNumber: 36
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Pill, {
                                                            status: r.titleStatus,
                                                            t: t
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 376,
                                                            columnNumber: 60
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 375,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                                        $border: t.border,
                                                        $color: t.text,
                                                        $align: "center",
                                                        children: isBlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MissingSpan, {
                                                            $color: t.textFaint,
                                                            children: "—"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 380,
                                                            columnNumber: 36
                                                        }, this) : r.description ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LengthSpan, {
                                                            $color: r.descriptionStatus === "Pass" ? t.passText : t.failText,
                                                            children: [
                                                                r.descriptionLength,
                                                                " chars"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 382,
                                                            columnNumber: 29
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MissingSpan, {
                                                            $color: t.textFaint,
                                                            children: "(missing)"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 383,
                                                            columnNumber: 29
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 379,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                                        $border: t.border,
                                                        $color: t.text,
                                                        $align: "center",
                                                        children: isBlocked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BlockedPill, {
                                                            t: t
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 386,
                                                            columnNumber: 36
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Pill, {
                                                            status: r.descriptionStatus,
                                                            t: t
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ResultsTable.tsx",
                                                            lineNumber: 386,
                                                            columnNumber: 60
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ResultsTable.tsx",
                                                        lineNumber: 385,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/ResultsTable.tsx",
                                                lineNumber: 345,
                                                columnNumber: 19
                                            }, this),
                                            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpandedRow, {
                                                r: r,
                                                colSpan: 6,
                                                t: t
                                            }, void 0, false, {
                                                fileName: "[project]/components/ResultsTable.tsx",
                                                lineNumber: 389,
                                                columnNumber: 30
                                            }, this)
                                        ]
                                    }, r.url, true, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 344,
                                        columnNumber: 17
                                    }, this);
                                }),
                                visible.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                        colSpan: 6,
                                        $border: t.border,
                                        $color: t.textFaint,
                                        $align: "center",
                                        style: {
                                            padding: "2rem"
                                        },
                                        children: "No issues detected — this filter is clear."
                                    }, void 0, false, {
                                        fileName: "[project]/components/ResultsTable.tsx",
                                        lineNumber: 396,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ResultsTable.tsx",
                                    lineNumber: 395,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ResultsTable.tsx",
                            lineNumber: 338,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ResultsTable.tsx",
                    lineNumber: 327,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ResultsTable.tsx",
                lineNumber: 326,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Footer, {
                $border: t.border,
                $bg: toolbarBg,
                $color: allPass ? t.successText : t.warnText,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconWrap, {
                        children: [
                            allPass ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCheckboxCircleFill"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 407,
                                columnNumber: 22
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseCircleFill"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/components/ResultsTable.tsx",
                                lineNumber: 407,
                                columnNumber: 59
                            }, this),
                            allPass ? `Scan complete — all ${results.length} pages passed.` : `${failCount} of ${results.length} pages need attention.`
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 406,
                        columnNumber: 9
                    }, this),
                    scanTimer?.duration != null && scanTimer.status != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExecutionBadge, {
                        $color: t.textMuted,
                        children: [
                            "· ",
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$duration$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executionLabel"])(scanTimer.status, (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$duration$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDuration"])(scanTimer.duration), "Scanned")
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ResultsTable.tsx",
                        lineNumber: 413,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ResultsTable.tsx",
                lineNumber: 405,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ResultsTable.tsx",
        lineNumber: 290,
        columnNumber: 5
    }, this);
}
_s(ResultsTable, "JQKfA7p8KdRMosy9jprwjLDvk/8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c27 = ResultsTable;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27;
__turbopack_context__.k.register(_c, "TableWrap");
__turbopack_context__.k.register(_c1, "Toolbar");
__turbopack_context__.k.register(_c2, "ToolbarLeft");
__turbopack_context__.k.register(_c3, "FilterBtn");
__turbopack_context__.k.register(_c4, "CopyBtn");
__turbopack_context__.k.register(_c5, "ScrollWrap");
__turbopack_context__.k.register(_c6, "Table");
__turbopack_context__.k.register(_c7, "Th");
__turbopack_context__.k.register(_c8, "Td");
__turbopack_context__.k.register(_c9, "DataRow");
__turbopack_context__.k.register(_c10, "ExpandCell");
__turbopack_context__.k.register(_c11, "UrlCell");
__turbopack_context__.k.register(_c12, "UrlAnchor");
__turbopack_context__.k.register(_c13, "SubLine");
__turbopack_context__.k.register(_c14, "PillSpan");
__turbopack_context__.k.register(_c15, "LengthSpan");
__turbopack_context__.k.register(_c16, "MissingSpan");
__turbopack_context__.k.register(_c17, "ExpandedTd");
__turbopack_context__.k.register(_c18, "ExpandedGrid");
__turbopack_context__.k.register(_c19, "ExpandedFieldLabel");
__turbopack_context__.k.register(_c20, "ExpandedValue");
__turbopack_context__.k.register(_c21, "Footer");
__turbopack_context__.k.register(_c22, "ExecutionBadge");
__turbopack_context__.k.register(_c23, "IconWrap");
__turbopack_context__.k.register(_c24, "Pill");
__turbopack_context__.k.register(_c25, "BlockedPill");
__turbopack_context__.k.register(_c26, "ExpandedRow");
__turbopack_context__.k.register(_c27, "ResultsTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/history.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Recent search history — localStorage persistence helpers.
//
// Each entry stores enough to restore the input field it came from.
// Max 5 items; duplicates are moved to the top rather than re-added.
__turbopack_context__.s([
    "MAX_RECENT_SEARCHES",
    ()=>MAX_RECENT_SEARCHES,
    "addHistoryEntry",
    ()=>addHistoryEntry,
    "clearHistory",
    ()=>clearHistory,
    "entryLabel",
    ()=>entryLabel,
    "loadHistory",
    ()=>loadHistory,
    "normalizeValue",
    ()=>normalizeValue,
    "saveHistory",
    ()=>saveHistory
]);
const STORAGE_KEY = "seo_checker_history";
const MAX_RECENT_SEARCHES = 5;
const MAX_ENTRIES = MAX_RECENT_SEARCHES;
// ── Normalisation ─────────────────────────────────────────────────────────────
/**
 * Normalise a URL for dedup comparison.
 * Strips trailing slash, lowercases scheme+host, preserves path case.
 */ function normalizeUrl(raw) {
    try {
        const u = new URL(raw.trim());
        const path = u.pathname.replace(/\/$/, "") || "/";
        return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}${path}${u.search}`;
    } catch  {
        return raw.trim().toLowerCase();
    }
}
function normalizeManual(raw) {
    // Normalise line endings and trim each line for comparison
    return raw.split("\n").map((l)=>l.trim()).filter(Boolean).join("\n").toLowerCase();
}
function normalizeValue(type, value) {
    return type === "url" ? normalizeUrl(value) : normalizeManual(value);
}
function loadHistory() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return [];
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return [];
        const trimmed = parsed.slice(0, MAX_ENTRIES);
        // Re-save if we trimmed stale over-limit data
        if (trimmed.length < parsed.length) {
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
            } catch  {}
        }
        return trimmed;
    } catch  {
        return [];
    }
}
function saveHistory(entries) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    } catch  {
    // Storage quota exceeded or unavailable — fail silently
    }
}
function clearHistory() {
    try {
        localStorage.removeItem(STORAGE_KEY);
    } catch  {
    // ignore
    }
}
function addHistoryEntry(current, type, value) {
    const normalized = normalizeValue(type, value);
    // Remove existing duplicate (same type + normalizedValue)
    const deduped = current.filter((e)=>!(e.type === type && e.normalizedValue === normalized));
    const entry = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type,
        value,
        normalizedValue: normalized,
        createdAt: Date.now()
    };
    // Prepend and cap
    return [
        entry,
        ...deduped
    ].slice(0, MAX_ENTRIES);
}
// ── Display helpers ───────────────────────────────────────────────────────────
const MANUAL_PREVIEW_MAX = 60;
function entryLabel(entry) {
    if (entry.type === "url") return entry.value;
    const lines = entry.value.split("\n").map((l)=>l.trim()).filter(Boolean);
    if (lines.length === 0) return entry.value;
    const first = lines[0].length > MANUAL_PREVIEW_MAX ? lines[0].slice(0, MANUAL_PREVIEW_MAX) + "…" : lines[0];
    return lines.length > 1 ? `${first} (+${lines.length - 1} more)` : first;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/RecentSearches.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecentSearches
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/history.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// ── Styled ────────────────────────────────────────────────────────────────────
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "RecentSearches__Wrap",
    componentId: "sc-571bea1c-0"
})` margin-bottom: 1.5rem; `;
_c = Wrap;
const Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "RecentSearches__Header",
    componentId: "sc-571bea1c-1"
})`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
`;
_c1 = Header;
const SectionTitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "RecentSearches__SectionTitle",
    componentId: "sc-571bea1c-2"
})`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 600;
  color: ${(p)=>p.$color};
`;
_c2 = SectionTitle;
const ClearBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "RecentSearches__ClearBtn",
    componentId: "sc-571bea1c-3"
})`
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: ${(p)=>p.$color};
  background: none;
  border: none;
  cursor: pointer;
  padding: 2px 4px;
  font-family: inherit;
  opacity: 0.8;
  &:hover { opacity: 1; }
`;
_c3 = ClearBtn;
const EmptyText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "RecentSearches__EmptyText",
    componentId: "sc-571bea1c-4"
})`
  font-size: 13px;
  color: ${(p)=>p.$color};
  margin: 0;
  font-style: italic;
`;
_c4 = EmptyText;
const List = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ul.withConfig({
    displayName: "RecentSearches__List",
    componentId: "sc-571bea1c-5"
})`
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
`;
_c5 = List;
const EntryBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "RecentSearches__EntryBtn",
    componentId: "sc-571bea1c-6"
})`
  width: 100%;
  text-align: left;
  padding: 7px 12px;
  border-radius: 7px;
  border: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  cursor: pointer;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  font-family: inherit;
  transition: filter 0.12s, transform 0.1s;
  &:hover { filter: brightness(0.96); }
  &:active { transform: scale(0.99); }
`;
_c6 = EntryBtn;
const Badge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "RecentSearches__Badge",
    componentId: "sc-571bea1c-7"
})`
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 11px;
  font-weight: 700;
  padding: 1px 7px;
  border-radius: 20px;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
`;
_c7 = Badge;
const EntryLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "RecentSearches__EntryLabel",
    componentId: "sc-571bea1c-8"
})`
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
`;
_c8 = EntryLabel;
const TimeStamp = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "RecentSearches__TimeStamp",
    componentId: "sc-571bea1c-9"
})`
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 11px;
  color: ${(p)=>p.$color};
`;
_c9 = TimeStamp;
// ── Helpers ───────────────────────────────────────────────────────────────────
function relativeTime(ts) {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60_000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
}
function RecentSearches({ entries, onSelect, onClear }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Header, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionTitle, {
                        $color: t.textMuted,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiTimeLine"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/components/RecentSearches.tsx",
                                lineNumber: 137,
                                columnNumber: 11
                            }, this),
                            " Recent Searches"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecentSearches.tsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this),
                    entries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ClearBtn, {
                        onClick: onClear,
                        $color: t.textFaint,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiDeleteBinLine"], {
                                size: 13
                            }, void 0, false, {
                                fileName: "[project]/components/RecentSearches.tsx",
                                lineNumber: 141,
                                columnNumber: 13
                            }, this),
                            " Clear"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecentSearches.tsx",
                        lineNumber: 140,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/RecentSearches.tsx",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            entries.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyText, {
                $color: t.textFaint,
                children: "No recent searches yet."
            }, void 0, false, {
                fileName: "[project]/components/RecentSearches.tsx",
                lineNumber: 147,
                columnNumber: 9
            }, this),
            entries.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(List, {
                children: entries.map((entry)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EntryBtn, {
                            onClick: ()=>onSelect(entry),
                            title: entry.value,
                            $border: t.border,
                            $bg: t.bgSubtle,
                            $color: t.text,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
                                    $bg: entry.type === "url" ? t.passBg : t.bgMuted,
                                    $color: entry.type === "url" ? t.passText : t.textMuted,
                                    children: [
                                        entry.type === "url" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiGlobalLine"], {
                                            size: 11
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecentSearches.tsx",
                                            lineNumber: 165,
                                            columnNumber: 43
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiListCheck"], {
                                            size: 11
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecentSearches.tsx",
                                            lineNumber: 165,
                                            columnNumber: 72
                                        }, this),
                                        entry.type === "url" ? "URL" : "Manual"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RecentSearches.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EntryLabel, {
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["entryLabel"])(entry)
                                }, void 0, false, {
                                    fileName: "[project]/components/RecentSearches.tsx",
                                    lineNumber: 168,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TimeStamp, {
                                    $color: t.textFaint,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiTimeLine"], {
                                            size: 11
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecentSearches.tsx",
                                            lineNumber: 170,
                                            columnNumber: 19
                                        }, this),
                                        relativeTime(entry.createdAt)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RecentSearches.tsx",
                                    lineNumber: 169,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/RecentSearches.tsx",
                            lineNumber: 154,
                            columnNumber: 15
                        }, this)
                    }, entry.id, false, {
                        fileName: "[project]/components/RecentSearches.tsx",
                        lineNumber: 153,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/RecentSearches.tsx",
                lineNumber: 151,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/RecentSearches.tsx",
        lineNumber: 134,
        columnNumber: 5
    }, this);
}
_s(RecentSearches, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c10 = RecentSearches;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "Header");
__turbopack_context__.k.register(_c2, "SectionTitle");
__turbopack_context__.k.register(_c3, "ClearBtn");
__turbopack_context__.k.register(_c4, "EmptyText");
__turbopack_context__.k.register(_c5, "List");
__turbopack_context__.k.register(_c6, "EntryBtn");
__turbopack_context__.k.register(_c7, "Badge");
__turbopack_context__.k.register(_c8, "EntryLabel");
__turbopack_context__.k.register(_c9, "TimeStamp");
__turbopack_context__.k.register(_c10, "RecentSearches");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/sitemapGroups.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Pure utility for deriving dynamic sitemap groups from crawl results.
// No React, no side effects.
__turbopack_context__.s([
    "extractDynamicGroups",
    ()=>extractDynamicGroups,
    "labelFromDPagesSitemapUrl",
    ()=>labelFromDPagesSitemapUrl
]);
function labelFromDPagesSitemapUrl(url) {
    // Step 1: extract the filename (last path segment)
    const filename = url.split("/").pop() ?? url;
    // Step 2 & 3: strip sitemap- prefix and -dpages.xml suffix
    let segment = filename;
    if (segment.startsWith("sitemap-")) {
        segment = segment.slice("sitemap-".length);
    }
    if (segment.endsWith("-dpages.xml")) {
        segment = segment.slice(0, segment.length - "-dpages.xml".length);
    } else if (segment.endsWith(".xml")) {
        // suffix wasn't -dpages.xml — strip .xml for the fallback path
        segment = segment.slice(0, segment.length - ".xml".length);
    }
    // Step 4: title-case the segment
    const titled = segment.split("-").map((word)=>word.length > 0 ? word[0].toUpperCase() + word.slice(1) : word).join("-");
    // Step 5: if empty, fall back to filename minus .xml
    if (titled.length === 0) {
        return filename.endsWith(".xml") ? filename.slice(0, filename.length - ".xml".length) : filename;
    }
    return titled;
}
function extractDynamicGroups(sitemapUrls) {
    return sitemapUrls.filter((url)=>{
        const filename = url.split("/").pop() ?? "";
        return filename.endsWith("-dpages.xml");
    }).map((url)=>({
            label: labelFromDPagesSitemapUrl(url),
            sitemapUrl: url
        }));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/filter.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// URL filtering pipeline for scan scope selection.
//
// Three modes:
//   "all"     — include every discovered URL
//   "static"  — include only URLs from sitemap-static.xml
//   "dynamic" — include only URLs from sitemaps ending in -dpages.xml
//
// Filtering is based solely on sourceSitemap — no URL shape analysis.
__turbopack_context__.s([
    "computeClientFilter",
    ()=>computeClientFilter,
    "filterUrls",
    ()=>filterUrls
]);
// ─── Helpers ─────────────────────────────────────────────────────────────────
/**
 * Returns true if the sitemap URL is a dynamic-pages sitemap (ends in -dpages.xml).
 */ function isDPagesSitemap(sitemapUrl) {
    try {
        const path = new URL(sitemapUrl).pathname;
        return path.endsWith("-dpages.xml");
    } catch  {
        return sitemapUrl.endsWith("-dpages.xml");
    }
}
/**
 * Returns true if the sitemap URL is the static sitemap (sitemap-static.xml).
 */ function isStaticSitemap(sitemapUrl) {
    try {
        const path = new URL(sitemapUrl).pathname;
        return path.endsWith("sitemap-static.xml");
    } catch  {
        return sitemapUrl.endsWith("sitemap-static.xml");
    }
}
/**
 * Checks whether a URL matches a glob-style exclude pattern.
 * Supports trailing wildcard only: "/blog/*" matches "/blog/anything".
 */ function matchesPattern(url, pattern) {
    try {
        const pathname = new URL(url).pathname;
        if (pattern.endsWith("/*")) {
            const prefix = pattern.slice(0, -2);
            return pathname === prefix || pathname.startsWith(prefix + "/");
        }
        return pathname === pattern;
    } catch  {
        return false;
    }
}
function computeClientFilter(entries, scope, excludedGroups = []) {
    return filterUrls(entries, scope, excludedGroups);
}
function filterUrls(entries, scope, excludePatterns = []) {
    const totalDiscovered = entries.length;
    const excluded = [];
    // ── Step 1: apply manual exclude patterns ──────────────────────────────────
    const afterPatternExclusion = entries.filter(({ url, sourceSitemap })=>{
        const blocked = excludePatterns.some((p)=>p.startsWith("http") ? sourceSitemap === p // sitemap URL match (new)
             : matchesPattern(url, p) // glob path match (existing)
        );
        if (blocked) excluded.push(url);
        return !blocked;
    });
    // ── Step 2: apply scope filter ─────────────────────────────────────────────
    const included = [];
    for (const { url, sourceSitemap } of afterPatternExclusion){
        let keep = false;
        if (scope === "all") {
            keep = true;
        } else if (scope === "static") {
            keep = isStaticSitemap(sourceSitemap);
        } else if (scope === "dynamic") {
            keep = isDPagesSitemap(sourceSitemap);
        }
        if (keep) {
            included.push(url);
        } else {
            excluded.push(url);
        }
    }
    return {
        includedUrls: included,
        excludedUrls: excluded,
        collapsedMappings: {},
        groupedPathCounts: [],
        excludedPatterns: excludePatterns,
        totalDiscovered,
        totalAfterFiltering: included.length,
        totalCollapsed: 0
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/scan/benchmarkUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Benchmark utility functions — pure, no React, no side effects.
//
// To remove the benchmark feature later, delete this file along with
// benchmarkTypes.ts and components/BenchmarkComparisonTable.tsx.
__turbopack_context__.s([
    "compareResults",
    ()=>compareResults,
    "compareSpeed",
    ()=>compareSpeed,
    "computeMetrics",
    ()=>computeMetrics,
    "createSnapshot",
    ()=>createSnapshot,
    "fmtDuration",
    ()=>fmtDuration,
    "isFairComparison",
    ()=>isFairComparison
]);
function createSnapshot(urls, scope, limit, exclusions) {
    return {
        urls: [
            ...urls
        ],
        scanScope: scope,
        scanLimit: limit,
        queueSize: urls.length,
        exclusions: [
            ...exclusions
        ],
        capturedAt: Date.now()
    };
}
function computeMetrics(pipeline, results, durationMs, opts) {
    const successCount = results.filter((r)=>r.scanStatus === "success").length;
    const blockedCount = results.filter((r)=>r.scanStatus === "Blocked (automation)").length;
    const errorCount = results.filter((r)=>r.scanStatus === "scan_error").length;
    const failedCount = results.filter((r)=>r.titleStatus === "Fail" || r.descriptionStatus === "Fail").length;
    const fetchCount = results.filter((r)=>r.methodUsed === "fetch").length;
    const playwrightCount = results.filter((r)=>r.methodUsed === "playwright").length;
    const urlsScanned = results.length;
    const avgTimePerPageMs = urlsScanned > 0 ? Math.round(durationMs / urlsScanned) : 0;
    return {
        pipeline,
        performanceMode: opts.performanceMode ?? null,
        runMode: opts.runMode,
        totalDurationMs: durationMs,
        avgTimePerPageMs,
        urlsQueued: opts.urlsQueued,
        urlsScanned,
        successCount,
        failedCount,
        blockedCount,
        errorCount,
        fetchCount,
        playwrightCount,
        scanScope: opts.scanScope,
        scanLimit: opts.scanLimit,
        queueSize: opts.urlsQueued,
        concurrency: opts.concurrency,
        browserReuse: opts.browserReuse,
        cacheMode: opts.runMode === "cold" ? "no-store" : "default",
        ranAt: Date.now()
    };
}
function compareResults(a, b) {
    const mapB = new Map(b.map((r)=>[
            r.url,
            r
        ]));
    const compared = a.filter((r)=>mapB.has(r.url));
    if (compared.length === 0) {
        return {
            totalCompared: 0,
            titleMatch: 0,
            titleMismatch: 0,
            descriptionMatch: 0,
            descriptionMismatch: 0,
            statusMatch: 0,
            statusMismatch: 0,
            matchRate: 0
        };
    }
    let titleMatch = 0, titleMismatch = 0;
    let descriptionMatch = 0, descriptionMismatch = 0;
    let statusMatch = 0, statusMismatch = 0;
    for (const ra of compared){
        const rb = mapB.get(ra.url);
        ra.title === rb.title ? titleMatch++ : titleMismatch++;
        ra.description === rb.description ? descriptionMatch++ : descriptionMismatch++;
        ra.scanStatus === rb.scanStatus ? statusMatch++ : statusMismatch++;
    }
    const totalFields = compared.length * 3;
    const matchedFields = titleMatch + descriptionMatch + statusMatch;
    const matchRate = totalFields > 0 ? matchedFields / totalFields : 0;
    return {
        totalCompared: compared.length,
        titleMatch,
        titleMismatch,
        descriptionMatch,
        descriptionMismatch,
        statusMatch,
        statusMismatch,
        matchRate
    };
}
function fmtDuration(ms) {
    if (ms <= 0) return "0.0s";
    if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
    const secs = Math.floor(ms / 1000);
    return `${Math.floor(secs / 60)}m ${String(secs % 60).padStart(2, "0")}s`;
}
function compareSpeed(a, b) {
    const diff = a - b;
    if (Math.abs(diff) < 200) return "same"; // < 200ms difference = negligible
    return diff < 0 ? "faster" : "slower";
}
function isFairComparison(a, b) {
    return a.runMode === b.runMode && a.queueSize === b.queueSize && a.scanScope === b.scanScope && a.scanLimit === b.scanLimit;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/BenchmarkComparisonTable.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BenchmarkComparisonTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// BenchmarkComparisonTable — side-by-side pipeline comparison.
// To remove: delete this file, scan/benchmarkUtils.ts, scan/benchmarkTypes.ts,
// and remove benchmark state + <BenchmarkComparisonTable> from app/page.tsx.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/scan/benchmarkUtils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
// ── Styled ────────────────────────────────────────────────────────────────────
const Wrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__Wrap",
    componentId: "sc-6d696213-0"
})`
  border: 1px solid ${(p)=>p.$border};
  border-radius: 10px;
  overflow: hidden;
  margin-bottom: 1.5rem;
  font-size: 13px;
`;
_c = Wrap;
const Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__Header",
    componentId: "sc-6d696213-1"
})`
  padding: 12px 16px;
  background: ${(p)=>p.$bg};
  border-bottom: 1px solid ${(p)=>p.$border};
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
_c1 = Header;
const Title = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "BenchmarkComparisonTable__Title",
    componentId: "sc-6d696213-2"
})`
  font-weight: 700;
  font-size: 14px;
  color: ${(p)=>p.$color};
`;
_c2 = Title;
const ResetBtn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "BenchmarkComparisonTable__ResetBtn",
    componentId: "sc-6d696213-3"
})`
  padding: 4px 12px;
  font-size: 12px;
  font-weight: 600;
  border-radius: 6px;
  border: 1px solid ${(p)=>p.$border};
  background: transparent;
  color: ${(p)=>p.$color};
  cursor: pointer;
  font-family: inherit;
  &:hover { opacity: 0.8; }
`;
_c3 = ResetBtn;
const WarningBanner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__WarningBanner",
    componentId: "sc-6d696213-4"
})`
  padding: 8px 16px;
  background: ${(p)=>p.$bg};
  border-bottom: 1px solid ${(p)=>p.$border};
  font-size: 12px;
  color: ${(p)=>p.$color};
  display: flex;
  align-items: center;
  gap: 6px;
`;
_c4 = WarningBanner;
const Table = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].table.withConfig({
    displayName: "BenchmarkComparisonTable__Table",
    componentId: "sc-6d696213-5"
})` width: 100%; border-collapse: collapse; `;
_c5 = Table;
const Th = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].th.withConfig({
    displayName: "BenchmarkComparisonTable__Th",
    componentId: "sc-6d696213-6"
})`
  padding: 9px 14px;
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: ${(p)=>p.$color};
  background: ${(p)=>p.$bg};
  border-bottom: 1px solid ${(p)=>p.$border};
  text-align: ${(p)=>p.$align ?? "left"};
  white-space: nowrap;
`;
_c6 = Th;
const Td = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].td.withConfig({
    displayName: "BenchmarkComparisonTable__Td",
    componentId: "sc-6d696213-7"
})`
  padding: 9px 14px;
  border-bottom: 1px solid ${(p)=>p.$border};
  color: ${(p)=>p.$color};
  text-align: ${(p)=>p.$align ?? "left"};
  background: ${(p)=>p.$highlight && p.$highlightBg ? p.$highlightBg : "transparent"};
  font-weight: ${(p)=>p.$highlight ? 600 : 400};
`;
_c7 = Td;
const MetricLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].td.withConfig({
    displayName: "BenchmarkComparisonTable__MetricLabel",
    componentId: "sc-6d696213-8"
})`
  padding: 9px 14px;
  border-bottom: 1px solid ${(p)=>p.$border};
  color: ${(p)=>p.$color};
  background: ${(p)=>p.$bg};
  font-weight: 500;
  white-space: nowrap;
`;
_c8 = MetricLabel;
const Badge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "BenchmarkComparisonTable__Badge",
    componentId: "sc-6d696213-9"
})`
  display: inline-block;
  padding: 1px 7px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 700;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  margin-left: 6px;
`;
_c9 = Badge;
const SectionHeader = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].tr.withConfig({
    displayName: "BenchmarkComparisonTable__SectionHeader",
    componentId: "sc-6d696213-10"
})`
  background: ${(p)=>p.$bg};
`;
_c10 = SectionHeader;
const SectionTd = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].td.withConfig({
    displayName: "BenchmarkComparisonTable__SectionTd",
    componentId: "sc-6d696213-11"
})`
  padding: 6px 14px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  color: ${(p)=>p.$color};
  border-bottom: 1px solid ${(p)=>p.$border};
`;
_c11 = SectionTd;
const ConsistencyWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyWrap",
    componentId: "sc-6d696213-12"
})`
  padding: 12px 16px;
  border-top: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$bg};
`;
_c12 = ConsistencyWrap;
const ConsistencyTitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyTitle",
    componentId: "sc-6d696213-13"
})`
  font-weight: 600;
  font-size: 13px;
  color: ${(p)=>p.$color};
  margin-bottom: 8px;
`;
_c13 = ConsistencyTitle;
const ConsistencyGrid = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyGrid",
    componentId: "sc-6d696213-14"
})`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
`;
_c14 = ConsistencyGrid;
const ConsistencyCell = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyCell",
    componentId: "sc-6d696213-15"
})`
  border: 1px solid ${(p)=>p.$border};
  border-radius: 6px;
  padding: 8px 10px;
  background: ${(p)=>p.$bg};
  text-align: center;
`;
_c15 = ConsistencyCell;
const ConsistencyValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyValue",
    componentId: "sc-6d696213-16"
})`
  font-size: 18px;
  font-weight: 700;
  color: ${(p)=>p.$color};
`;
_c16 = ConsistencyValue;
const ConsistencyLabel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__ConsistencyLabel",
    componentId: "sc-6d696213-17"
})`
  font-size: 11px;
  color: ${(p)=>p.$color};
  text-transform: uppercase;
  letter-spacing: 0.04em;
  margin-top: 2px;
`;
_c17 = ConsistencyLabel;
const NotesWrap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__NotesWrap",
    componentId: "sc-6d696213-18"
})`
  padding: 10px 16px;
  border-top: 1px solid ${(p)=>p.$border};
  background: ${(p)=>p.$bg};
`;
_c18 = NotesWrap;
const NoteItem = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "BenchmarkComparisonTable__NoteItem",
    componentId: "sc-6d696213-19"
})`
  font-size: 12px;
  color: ${(p)=>p.$color};
  margin-bottom: 3px;
  &:last-child { margin-bottom: 0; }
  &::before { content: "ℹ "; }
`;
_c19 = NoteItem;
// ── Helpers ───────────────────────────────────────────────────────────────────
function pct(n, total) {
    if (total === 0) return "—";
    return `${Math.round(n / total * 100)}%`;
}
function winnerBadge(aVal, bVal, lowerIsBetter, t) {
    if (aVal === bVal) return null;
    const aWins = lowerIsBetter ? aVal < bVal : aVal > bVal;
    return aWins ? {
        a: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            $bg: t.passBg,
            $color: t.passText,
            children: "faster"
        }, void 0, false, {
            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
            lineNumber: 195,
            columnNumber: 12
        }, this),
        b: null
    } : {
        a: null,
        b: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            $bg: t.passBg,
            $color: t.passText,
            children: "faster"
        }, void 0, false, {
            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
            lineNumber: 196,
            columnNumber: 21
        }, this)
    };
}
function BenchmarkComparisonTable({ previous, improved, previousResults, improvedResults, onReset }) {
    _s();
    const { theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const hasPrev = !!previous;
    const hasImpr = !!improved;
    const hasBoth = hasPrev && hasImpr;
    if (!hasPrev && !hasImpr) return null;
    const fair = hasBoth ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFairComparison"])(previous, improved) : true;
    const consistency = hasBoth && previousResults && improvedResults ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareResults"])(previousResults, improvedResults) : null;
    const durationWinner = hasBoth ? winnerBadge(previous.totalDurationMs, improved.totalDurationMs, true, t) : null;
    const avgWinner = hasBoth ? winnerBadge(previous.avgTimePerPageMs, improved.avgTimePerPageMs, true, t) : null;
    // Auto-generated notes
    const notes = [];
    if (improved) {
        const modeLabel = improved.performanceMode ?? "balanced";
        notes.push(`Improved Process ran in ${modeLabel} mode · ${improved.concurrency ?? 1} worker${(improved.concurrency ?? 1) > 1 ? "s" : ""} · cache: ${improved.cacheMode}.`);
        if (improved.playwrightCount > improved.urlsScanned * 0.5) notes.push("Improved Process had heavy Playwright fallback — may be slower on lower-end PCs.");
    }
    if (previous) notes.push(`Previous Process · sequential · cache: ${previous.cacheMode}.`);
    if (hasBoth && previous.runMode !== improved.runMode) notes.push("Run modes differ — cold vs warm cache — timing comparison may not be fair.");
    if (hasBoth && previous.playwrightCount < improved.playwrightCount) notes.push("Previous Process had fewer Playwright fallbacks — may be more stable on blocked pages.");
    if (hasBoth && consistency && consistency.matchRate < 0.9) notes.push(`Result consistency is ${Math.round(consistency.matchRate * 100)}% — pipelines disagree on some pages.`);
    const timingRows = [
        {
            label: "Total Duration",
            prev: previous ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtDuration"])(previous.totalDurationMs) : "—",
            impr: improved ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtDuration"])(improved.totalDurationMs) : "—"
        },
        {
            label: "Avg Time / Page",
            prev: previous ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtDuration"])(previous.avgTimePerPageMs) : "—",
            impr: improved ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtDuration"])(improved.avgTimePerPageMs) : "—"
        }
    ];
    const countRows = [
        {
            label: "URLs Queued",
            prev: previous?.urlsQueued ?? "—",
            impr: improved?.urlsQueued ?? "—"
        },
        {
            label: "URLs Scanned",
            prev: previous?.urlsScanned ?? "—",
            impr: improved?.urlsScanned ?? "—"
        },
        {
            label: "Successful",
            prev: previous?.successCount ?? "—",
            impr: improved?.successCount ?? "—"
        },
        {
            label: "Failed SEO",
            prev: previous?.failedCount ?? "—",
            impr: improved?.failedCount ?? "—"
        },
        {
            label: "Blocked Pages",
            prev: previous?.blockedCount ?? "—",
            impr: improved?.blockedCount ?? "—"
        },
        {
            label: "Errors",
            prev: previous?.errorCount ?? "—",
            impr: improved?.errorCount ?? "—"
        },
        {
            label: "Fetch Only",
            prev: previous?.fetchCount ?? "—",
            impr: improved?.fetchCount ?? "—"
        },
        {
            label: "Playwright Fallback",
            prev: previous?.playwrightCount ?? "—",
            impr: improved?.playwrightCount ?? "—"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Wrap, {
        $border: t.border,
        $bg: t.bg,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Header, {
                $bg: t.bgSubtle,
                $border: t.border,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Title, {
                        $color: t.text,
                        children: [
                            "Pipeline Benchmark Comparison",
                            hasBoth && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
                                $bg: fair ? t.passBg : t.warnBg,
                                $color: fair ? t.passText : t.warnText,
                                children: fair ? "fair comparison" : "⚠ conditions differ"
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 267,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 264,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            alignItems: "center",
                            gap: 10
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontSize: 12,
                                    color: t.textFaint
                                },
                                children: hasBoth ? "Both pipelines ran" : "Run both pipelines to compare"
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            onReset && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ResetBtn, {
                                $border: t.failText,
                                $color: t.failText,
                                onClick: onReset,
                                children: "Reset"
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 280,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 275,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                lineNumber: 263,
                columnNumber: 7
            }, this),
            hasBoth && !fair && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WarningBanner, {
                $bg: t.warnBg,
                $border: t.border,
                $color: t.warnText,
                children: [
                    "⚠ Warning: ",
                    previous.runMode !== improved.runMode ? `Previous ran as ${previous.runMode} cache, Improved ran as ${improved.runMode} cache — timing is not directly comparable.` : "Scan configurations differ between runs — results may not be directly comparable."
                ]
            }, void 0, true, {
                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                lineNumber: 289,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Table, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                    $bg: t.headerBg,
                                    $border: t.border,
                                    $color: t.textMuted,
                                    style: {
                                        width: "34%"
                                    },
                                    children: "Metric"
                                }, void 0, false, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 299,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                    $bg: t.headerBg,
                                    $border: t.border,
                                    $color: t.textMuted,
                                    $align: "center",
                                    children: [
                                        "Previous Process",
                                        previous && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                fontWeight: 400,
                                                fontSize: 11,
                                                color: t.textFaint,
                                                textTransform: "none",
                                                letterSpacing: 0
                                            },
                                            children: [
                                                previous.runMode,
                                                " · ",
                                                new Date(previous.ranAt).toLocaleTimeString()
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 303,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 300,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Th, {
                                    $bg: t.headerBg,
                                    $border: t.border,
                                    $color: t.textMuted,
                                    $align: "center",
                                    children: [
                                        "Improved Process",
                                        improved && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                fontWeight: 400,
                                                fontSize: 11,
                                                color: t.textFaint,
                                                textTransform: "none",
                                                letterSpacing: 0
                                            },
                                            children: [
                                                improved.runMode,
                                                " · ",
                                                new Date(improved.ranAt).toLocaleTimeString()
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 311,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 308,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                            lineNumber: 298,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 297,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionHeader, {
                                $bg: t.bgMuted,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionTd, {
                                    colSpan: 3,
                                    $color: t.textMuted,
                                    $border: t.border,
                                    children: "Timing"
                                }, void 0, false, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 320,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 319,
                                columnNumber: 11
                            }, this),
                            timingRows.map((row)=>{
                                const winner = row.label === "Total Duration" ? durationWinner : avgWinner;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MetricLabel, {
                                            $border: t.border,
                                            $color: t.text,
                                            $bg: t.bgSubtle,
                                            children: row.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 326,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: [
                                                previous ? row.prev : "—",
                                                winner?.a
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 327,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: [
                                                improved ? row.impr : "—",
                                                winner?.b
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 328,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, row.label, true, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 325,
                                    columnNumber: 15
                                }, this);
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionHeader, {
                                $bg: t.bgMuted,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionTd, {
                                    colSpan: 3,
                                    $color: t.textMuted,
                                    $border: t.border,
                                    children: "Result Counts"
                                }, void 0, false, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 334,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 333,
                                columnNumber: 11
                            }, this),
                            countRows.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MetricLabel, {
                                            $border: t.border,
                                            $color: t.text,
                                            $bg: t.bgSubtle,
                                            children: row.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 338,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: previous ? row.prev : "—"
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 339,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: improved ? row.impr : "—"
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 340,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, row.label, true, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 337,
                                    columnNumber: 13
                                }, this)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionHeader, {
                                $bg: t.bgMuted,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionTd, {
                                    colSpan: 3,
                                    $color: t.textMuted,
                                    $border: t.border,
                                    children: "Environment"
                                }, void 0, false, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 345,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 344,
                                columnNumber: 11
                            }, this),
                            [
                                {
                                    label: "Run Mode",
                                    prev: previous?.runMode ?? "—",
                                    impr: improved?.runMode ?? "—"
                                },
                                {
                                    label: "Cache Mode",
                                    prev: previous?.cacheMode ?? "—",
                                    impr: improved?.cacheMode ?? "—"
                                },
                                {
                                    label: "Scope",
                                    prev: previous?.scanScope ?? "—",
                                    impr: improved?.scanScope ?? "—"
                                },
                                {
                                    label: "Scan Limit",
                                    prev: previous ? previous.scanLimit ?? "none" : "—",
                                    impr: improved ? improved.scanLimit ?? "none" : "—"
                                },
                                {
                                    label: "Queue Size",
                                    prev: previous?.queueSize ?? "—",
                                    impr: improved?.queueSize ?? "—"
                                },
                                {
                                    label: "Concurrency",
                                    prev: previous ? previous.concurrency ?? "sequential" : "—",
                                    impr: improved ? improved.concurrency ?? "sequential" : "—"
                                },
                                {
                                    label: "Performance Mode",
                                    prev: previous ? previous.performanceMode ?? "—" : "—",
                                    impr: improved?.performanceMode ?? "—"
                                },
                                {
                                    label: "Browser Reuse",
                                    prev: previous ? previous.browserReuse ? "Yes" : "No" : "—",
                                    impr: improved ? improved.browserReuse ? "Yes" : "No" : "—"
                                }
                            ].map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MetricLabel, {
                                            $border: t.border,
                                            $color: t.text,
                                            $bg: t.bgSubtle,
                                            children: row.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 358,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: row.prev
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 359,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Td, {
                                            $border: t.border,
                                            $color: t.text,
                                            $align: "center",
                                            children: row.impr
                                        }, void 0, false, {
                                            fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                            lineNumber: 360,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, row.label, true, {
                                    fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                    lineNumber: 357,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 318,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                lineNumber: 296,
                columnNumber: 7
            }, this),
            consistency && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyWrap, {
                $border: t.border,
                $bg: t.bgSubtle,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyTitle, {
                        $color: t.text,
                        children: [
                            "Result Consistency — ",
                            consistency.totalCompared,
                            " URLs compared",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
                                $bg: consistency.matchRate >= 0.95 ? t.passBg : consistency.matchRate >= 0.8 ? t.warnBg : t.failBg,
                                $color: consistency.matchRate >= 0.95 ? t.passText : consistency.matchRate >= 0.8 ? t.warnText : t.failText,
                                children: [
                                    Math.round(consistency.matchRate * 100),
                                    "% match"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 370,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 368,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyGrid, {
                        children: [
                            {
                                label: "Title",
                                match: consistency.titleMatch,
                                mismatch: consistency.titleMismatch
                            },
                            {
                                label: "Description",
                                match: consistency.descriptionMatch,
                                mismatch: consistency.descriptionMismatch
                            },
                            {
                                label: "Status",
                                match: consistency.statusMatch,
                                mismatch: consistency.statusMismatch
                            },
                            {
                                label: "Overall",
                                match: consistency.titleMatch + consistency.descriptionMatch + consistency.statusMatch,
                                mismatch: consistency.titleMismatch + consistency.descriptionMismatch + consistency.statusMismatch
                            }
                        ].map(({ label, match, mismatch })=>{
                            const total = match + mismatch;
                            const rate = total > 0 ? match / total : 0;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyCell, {
                                $border: t.border,
                                $bg: t.bg,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyValue, {
                                        $color: rate >= 0.9 ? t.passText : rate >= 0.7 ? t.warnText : t.failText,
                                        children: pct(match, total)
                                    }, void 0, false, {
                                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                        lineNumber: 390,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConsistencyLabel, {
                                        $color: t.textMuted,
                                        children: label
                                    }, void 0, false, {
                                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                        lineNumber: 393,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: 11,
                                            color: t.textFaint,
                                            marginTop: 2
                                        },
                                        children: [
                                            match,
                                            "/",
                                            total
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                        lineNumber: 394,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, label, true, {
                                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                                lineNumber: 389,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 377,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                lineNumber: 367,
                columnNumber: 9
            }, this),
            notes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NotesWrap, {
                $border: t.border,
                $bg: t.bg,
                children: notes.map((n, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NoteItem, {
                        $color: t.textMuted,
                        children: n
                    }, i, false, {
                        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                        lineNumber: 404,
                        columnNumber: 32
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/BenchmarkComparisonTable.tsx",
                lineNumber: 403,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/BenchmarkComparisonTable.tsx",
        lineNumber: 262,
        columnNumber: 5
    }, this);
}
_s(BenchmarkComparisonTable, "JkSxfi8+JQlqgIgDOc3wQN+nVIw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c20 = BenchmarkComparisonTable;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20;
__turbopack_context__.k.register(_c, "Wrap");
__turbopack_context__.k.register(_c1, "Header");
__turbopack_context__.k.register(_c2, "Title");
__turbopack_context__.k.register(_c3, "ResetBtn");
__turbopack_context__.k.register(_c4, "WarningBanner");
__turbopack_context__.k.register(_c5, "Table");
__turbopack_context__.k.register(_c6, "Th");
__turbopack_context__.k.register(_c7, "Td");
__turbopack_context__.k.register(_c8, "MetricLabel");
__turbopack_context__.k.register(_c9, "Badge");
__turbopack_context__.k.register(_c10, "SectionHeader");
__turbopack_context__.k.register(_c11, "SectionTd");
__turbopack_context__.k.register(_c12, "ConsistencyWrap");
__turbopack_context__.k.register(_c13, "ConsistencyTitle");
__turbopack_context__.k.register(_c14, "ConsistencyGrid");
__turbopack_context__.k.register(_c15, "ConsistencyCell");
__turbopack_context__.k.register(_c16, "ConsistencyValue");
__turbopack_context__.k.register(_c17, "ConsistencyLabel");
__turbopack_context__.k.register(_c18, "NotesWrap");
__turbopack_context__.k.register(_c19, "NoteItem");
__turbopack_context__.k.register(_c20, "BenchmarkComparisonTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ModeTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ModeTabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ManualInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ManualInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SitemapInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SitemapInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SitemapDebug$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SitemapDebug.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ScopeSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ScopeSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ResultsTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ResultsTable.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecentSearches$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/RecentSearches.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/theme.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/history.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/urlValidation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sitemapGroups$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sitemapGroups.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$filter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/filter.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BenchmarkComparisonTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BenchmarkComparisonTable.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/scan/benchmarkUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/scan/types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MAX_MANUAL_URLS = 10;
// ── Styled layout ─────────────────────────────────────────────────────────────
const Main = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].main.withConfig({
    displayName: "page__Main",
    componentId: "sc-efa2cfa0-0"
})`
  max-width: 1100px;
  margin: 0 auto;
  padding: 1.5rem 1rem;
  color: ${(p)=>p.$color};

  @media (min-width: 640px) {
    padding: 2.5rem 1.5rem;
  }
`;
_c = Main;
const HeaderRow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "page__HeaderRow",
    componentId: "sc-efa2cfa0-1"
})`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 1.75rem;
`;
_c1 = HeaderRow;
const HeaderText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "page__HeaderText",
    componentId: "sc-efa2cfa0-2"
})``;
_c2 = HeaderText;
const PageTitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].h1.withConfig({
    displayName: "page__PageTitle",
    componentId: "sc-efa2cfa0-3"
})`
  font-size: 24px;
  font-weight: 700;
  margin: 0 0 4px;
`;
_c3 = PageTitle;
const PageSubtitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].p.withConfig({
    displayName: "page__PageSubtitle",
    componentId: "sc-efa2cfa0-4"
})`
  color: ${(p)=>p.$color};
  margin: 0;
`;
_c4 = PageSubtitle;
const ThemeToggle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].button.withConfig({
    displayName: "page__ThemeToggle",
    componentId: "sc-efa2cfa0-5"
})`
  margin-top: 4px;
  padding: 6px 12px;
  font-size: 13px;
  font-weight: 600;
  border-radius: 8px;
  border: 1px solid ${(p)=>p.$border};
  cursor: pointer;
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  flex-shrink: 0;
  align-self: flex-start;
  white-space: nowrap;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: background 0.15s, border-color 0.15s, opacity 0.15s;
  &:hover { opacity: 0.8; }
  &:active { opacity: 0.65; }
`;
_c5 = ThemeToggle;
const ErrorBanner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "page__ErrorBanner",
    componentId: "sc-efa2cfa0-6"
})`
  background: ${(p)=>p.$bg};
  color: ${(p)=>p.$color};
  padding: 0.75rem 1rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  font-size: 14px;
  word-break: break-word;
  overflow-wrap: break-word;
`;
_c6 = ErrorBanner;
const ErrorDetails = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].details.withConfig({
    displayName: "page__ErrorDetails",
    componentId: "sc-efa2cfa0-7"
})`
  margin-top: 6px;
  font-size: 12px;
  opacity: 0.8;
  & summary {
    cursor: pointer;
    user-select: none;
    display: inline;
  }
  & p {
    margin: 6px 0 0;
    word-break: break-all;
    overflow-wrap: break-word;
    line-height: 1.5;
  }
`;
_c7 = ErrorDetails;
/** Turns a raw error message into a friendly one-liner + optional detail block. */ function FriendlyError({ message, bg, color }) {
    const isNoSitemap = message.startsWith("No sitemap found");
    const friendly = isNoSitemap ? "No sitemap found for this URL." : message;
    const detail = isNoSitemap ? message : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ErrorBanner, {
        $bg: bg,
        $color: color,
        children: [
            friendly,
            detail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ErrorDetails, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                        children: "Show details"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: detail
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 126,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 124,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_c8 = FriendlyError;
// Summary bar shown between crawl and scan phases
const CrawlSummary = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].div.withConfig({
    displayName: "page__CrawlSummary",
    componentId: "sc-efa2cfa0-8"
})`
  background: ${(p)=>p.$bg};
  border: 1px solid ${(p)=>p.$border};
  border-radius: 8px;
  padding: 8px 14px;
  margin-bottom: 12px;
  font-size: 13px;
  color: ${(p)=>p.$color};
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
`;
_c9 = CrawlSummary;
const SummaryItem = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].span.withConfig({
    displayName: "page__SummaryItem",
    componentId: "sc-efa2cfa0-9"
})`
  & strong { color: ${(p)=>p.$accent}; }
`;
_c10 = SummaryItem;
function Home() {
    _s();
    const { theme, toggle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokens"][theme];
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("manual");
    const [manualInput, setManualInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [sitemapInput, setSitemapInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // ── Phase 1: discovery state ───────────────────────────────────────────────
    // crawlResult is the source of truth for all discovered URLs.
    // It is only replaced when the user crawls a new URL — never on filter changes.
    const [crawlResult, setCrawlResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // ── Phase 2: filter state ──────────────────────────────────────────────────
    // These drive liveFilter (derived via useMemo) without touching crawlResult.
    const [scope, setScope] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [selectedGroups, setSelectedGroups] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [scanLimit, setScanLimit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isCrawling, setIsCrawling] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isScanning, setIsScanning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [results, setResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pipelineUsed, setPipelineUsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [performanceMode, setPerformanceMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PERFORMANCE_MODE"]);
    const [benchmarkRunMode, setBenchmarkRunMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("cold");
    const [benchmarkSnapshot, setBenchmarkSnapshot] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Benchmark state — stored per pipeline so both can accumulate independently
    const [benchPrevious, setBenchPrevious] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [benchImproved, setBenchImproved] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [prevResults, setPrevResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [imprResults, setImprResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Scan execution timer
    const [scanTimer, setScanTimer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        duration: null,
        status: null
    });
    const scanStartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // AbortController refs — one per cancellable operation
    const crawlAbortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scanAbortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Session counter — incremented on each new scan so stale responses are ignored
    const scanSessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const isProcessing = isCrawling || isScanning;
    // ── Derived state ──────────────────────────────────────────────────────────
    // liveFilter is computed instantly from crawlResult + scope + selectedGroups.
    // No useEffect, no setState — changing scope or exclusions updates this in one render.
    const dynamicGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Home.useMemo[dynamicGroups]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sitemapGroups$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractDynamicGroups"])(crawlResult?.sitemapUrls ?? [])
    }["Home.useMemo[dynamicGroups]"], [
        crawlResult
    ]);
    const liveFilter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Home.useMemo[liveFilter]": ()=>{
            if (!crawlResult) return null;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$filter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeClientFilter"])(crawlResult.pageEntries, scope, scope === "dynamic" ? selectedGroups : []);
        }
    }["Home.useMemo[liveFilter]"], [
        crawlResult,
        scope,
        selectedGroups
    ]);
    const availableCount = liveFilter?.totalAfterFiltering ?? 0;
    // Clamp scanLimit when the filtered count shrinks (e.g. scope change)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if (scanLimit !== "" && availableCount > 0 && scanLimit > availableCount) {
                setScanLimit(availableCount);
            } else if (availableCount === 0 && scanLimit !== "") {
                setScanLimit("");
            }
        }
    }["Home.useEffect"], [
        availableCount
    ]); // eslint-disable-line react-hooks/exhaustive-deps
    // Load history after mount to avoid SSR mismatch
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            setHistory((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadHistory"])());
        }
    }["Home.useEffect"], []);
    function pushHistory(updated) {
        setHistory(updated);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveHistory"])(updated);
    }
    function handleModeChange(next) {
        if (isProcessing) return;
        setMode(next);
        // Only clear crawl state on mode switch, not on filter changes
        setCrawlResult(null);
        setResults([]);
        setError(null);
    }
    // Called only when the sitemap URL input changes — clears crawl + scan state
    // so stale results from a previous URL don't linger.
    function handleSitemapUrlChange() {
        setCrawlResult(null);
        setResults([]);
        setError(null);
        setBenchPrevious(null);
        setBenchImproved(null);
        setPrevResults([]);
        setImprResults([]);
        setPipelineUsed(null);
        setBenchmarkSnapshot(null);
        setSelectedGroups([]);
    }
    function resetBenchmark() {
        setBenchPrevious(null);
        setBenchImproved(null);
        setPrevResults([]);
        setImprResults([]);
        setPipelineUsed(null);
        setBenchmarkSnapshot(null);
    }
    // ── Manual scan ────────────────────────────────────────────────────────────
    async function handleManualScan() {
        const urls = manualInput.split("\n").map((u)=>u.trim()).filter(Boolean).slice(0, MAX_MANUAL_URLS);
        if (urls.length === 0) return;
        pushHistory((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addHistoryEntry"])(history, "manual", manualInput.trim()));
        const abort = new AbortController();
        scanAbortRef.current = abort;
        const sessionId = ++scanSessionRef.current;
        scanStartRef.current = Date.now();
        setScanTimer({
            duration: null,
            status: null
        });
        setIsScanning(true);
        setResults([]);
        setError(null);
        try {
            const { results: data } = await callScanApi(urls, undefined, abort.signal, "/api/scan-improved", performanceMode);
            if (sessionId === scanSessionRef.current && !abort.signal.aborted) {
                setResults(data);
                setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "completed"
                });
            }
        } catch (e) {
            if (e.name === "AbortError") {
                if (sessionId === scanSessionRef.current) setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "cancelled"
                });
            } else if (sessionId === scanSessionRef.current) {
                setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "failed"
                });
                setError(e instanceof Error ? e.message : "Something went wrong.");
            }
        } finally{
            if (sessionId === scanSessionRef.current) {
                setIsScanning(false);
                scanAbortRef.current = null;
            }
        }
    }
    function handleCancelScan() {
        scanAbortRef.current?.abort();
    }
    // ── Sitemap crawl (Phase 1) ────────────────────────────────────────────────
    // Fetches all URLs once and stores them in crawlResult.
    // Always crawls with scope="all" so the full dataset is available for client-side filtering.
    async function handleDiscover() {
        if (!sitemapInput) return;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidUrl"])(sitemapInput)) return;
        const crawlUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBaseUrlForSitemapCrawl"])(sitemapInput) ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$urlValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeUrlString"])(sitemapInput);
        pushHistory((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addHistoryEntry"])(history, "url", crawlUrl));
        const abort = new AbortController();
        crawlAbortRef.current = abort;
        setIsCrawling(true);
        setCrawlResult(null);
        setResults([]);
        setError(null);
        setSelectedGroups([]);
        try {
            const res = await fetch("/api/sitemap", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                // Always fetch all URLs — scope filtering is done client-side from this result
                body: JSON.stringify({
                    url: crawlUrl,
                    scope: "all",
                    excludePatterns: []
                }),
                signal: abort.signal
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error ?? "Could not load sitemap.");
            setCrawlResult(data);
        } catch (e) {
            if (e.name !== "AbortError") {
                setError(e instanceof Error ? e.message : "Something went wrong.");
            }
        } finally{
            setIsCrawling(false);
            crawlAbortRef.current = null;
        }
    }
    function handleCancelCrawl() {
        crawlAbortRef.current?.abort();
    }
    // ── Scan discovered pages (Phase 2) ───────────────────────────────────────
    // Uses liveFilter (derived from current scope + exclusions) as the URL list.
    // A benchmark snapshot is frozen at scan-start so both pipelines use identical inputs.
    async function handleScanDiscovered(pipeline = "improved") {
        if (!crawlResult || !liveFilter) return;
        const limit = scanLimit !== "" ? scanLimit : undefined;
        // Reuse the existing snapshot ONLY if it matches the current filter config —
        // this ensures benchmark comparisons use identical inputs across both pipelines.
        // If scope, exclusions, or limit changed, always create a fresh snapshot.
        const snapshotMatches = benchmarkSnapshot && benchmarkSnapshot.scanScope === scope && benchmarkSnapshot.scanLimit === (limit ?? null) && JSON.stringify(benchmarkSnapshot.exclusions) === JSON.stringify(selectedGroups);
        const snapshot = snapshotMatches ? benchmarkSnapshot : (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSnapshot"])(liveFilter.includedUrls, scope, limit ?? null, selectedGroups);
        if (!snapshotMatches) setBenchmarkSnapshot(snapshot);
        const urlsToScan = snapshot.urls;
        const abort = new AbortController();
        scanAbortRef.current = abort;
        const sessionId = ++scanSessionRef.current;
        scanStartRef.current = Date.now();
        setScanTimer({
            duration: null,
            status: null
        });
        setPipelineUsed(null);
        setIsScanning(true);
        setResults([]);
        setError(null);
        try {
            const apiRoute = pipeline === "improved" ? "/api/scan-improved" : "/api/scan";
            const perfMode = pipeline === "improved" ? performanceMode : undefined;
            const { results: data, durationMs } = await callScanApi(urlsToScan, limit, abort.signal, apiRoute, perfMode, benchmarkRunMode);
            if (sessionId === scanSessionRef.current && !abort.signal.aborted) {
                setResults(data);
                setPipelineUsed(pipeline);
                setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "completed"
                });
                const metrics = (0, __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$benchmarkUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeMetrics"])(pipeline, data, durationMs || Date.now() - (scanStartRef.current ?? Date.now()), {
                    urlsQueued: snapshot.queueSize,
                    scanScope: scope,
                    scanLimit: limit ?? null,
                    concurrency: pipeline === "improved" ? __TURBOPACK__imported__module__$5b$project$5d2f$scan$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PERFORMANCE_CONFIGS"][performanceMode].concurrency : null,
                    browserReuse: true,
                    performanceMode: pipeline === "improved" ? performanceMode : null,
                    runMode: benchmarkRunMode
                });
                if (pipeline === "previous") {
                    setBenchPrevious(metrics);
                    setPrevResults(data);
                } else {
                    setBenchImproved(metrics);
                    setImprResults(data);
                }
            }
        } catch (e) {
            if (e.name === "AbortError") {
                if (sessionId === scanSessionRef.current) setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "cancelled"
                });
            } else if (sessionId === scanSessionRef.current) {
                setScanTimer({
                    duration: Date.now() - (scanStartRef.current ?? Date.now()),
                    status: "failed"
                });
                setError(e instanceof Error ? e.message : "Something went wrong.");
            }
        } finally{
            if (sessionId === scanSessionRef.current) {
                setIsScanning(false);
                scanAbortRef.current = null;
            }
        }
    }
    function handleHistorySelect(entry) {
        if (isProcessing) return;
        if (entry.type === "url") {
            setMode("sitemap");
            setSitemapInput(entry.value);
        } else {
            setMode("manual");
            setManualInput(entry.value);
        }
        handleSitemapUrlChange();
    }
    function handleHistoryClear() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$history$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearHistory"])();
        setHistory([]);
    }
    async function callScanApi(urls, limit, signal, route = "/api/scan-improved", perfMode, runMode) {
        const res = await fetch(route, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                urls,
                ...limit !== undefined ? {
                    limit
                } : {},
                ...perfMode !== undefined ? {
                    performanceMode: perfMode
                } : {},
                ...runMode !== undefined ? {
                    runMode
                } : {}
            }),
            signal
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Scan failed.");
        return {
            results: data.results,
            durationMs: typeof data.durationMs === "number" ? data.durationMs : 0
        };
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Main, {
        $color: t.text,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeaderRow, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeaderText, {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PageTitle, {
                                children: "PurrScope"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 454,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PageSubtitle, {
                                $color: t.textMuted,
                                children: "Automated SEO & Compliance QA"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 455,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 453,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeToggle, {
                        onClick: toggle,
                        title: "Toggle light/dark mode",
                        $border: t.border,
                        $bg: t.bgMuted,
                        $color: t.text,
                        children: theme === "light" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiMoonLine"], {
                                    size: 14
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 460,
                                    columnNumber: 34
                                }, this),
                                " Dark"
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiSunLine"], {
                                    size: 14
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 460,
                                    columnNumber: 71
                                }, this),
                                " Light"
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 459,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 452,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ModeTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                mode: mode,
                onChange: handleModeChange,
                disabled: isProcessing
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 464,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecentSearches$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                entries: history,
                onSelect: handleHistorySelect,
                onClear: handleHistoryClear
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 466,
                columnNumber: 7
            }, this),
            mode === "manual" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ManualInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                value: manualInput,
                onChange: setManualInput,
                onScan: handleManualScan,
                loading: isScanning,
                onCancel: handleCancelScan,
                isProcessing: isProcessing
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 469,
                columnNumber: 9
            }, this),
            mode === "sitemap" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SitemapInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        value: sitemapInput,
                        onChange: setSitemapInput,
                        onScan: handleDiscover,
                        loading: isCrawling,
                        onCancel: handleCancelCrawl,
                        isScanning: isScanning,
                        onInputChange: handleSitemapUrlChange
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 475,
                        columnNumber: 11
                    }, this),
                    crawlResult && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CrawlSummary, {
                                $bg: t.bgSubtle,
                                $border: t.border,
                                $color: t.textMuted,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SummaryItem, {
                                        $accent: t.infoText,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: crawlResult.pageCount
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 492,
                                                columnNumber: 19
                                            }, this),
                                            " pages discovered"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 491,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SummaryItem, {
                                        $accent: t.passText,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: availableCount
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 495,
                                                columnNumber: 19
                                            }, this),
                                            " pages selected for scanning"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 494,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 490,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ScopeSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                scope: scope,
                                onScopeChange: (s)=>{
                                    setScope(s);
                                    if (s !== "dynamic") setSelectedGroups([]);
                                },
                                dynamicGroups: dynamicGroups,
                                selectedGroups: selectedGroups,
                                onSelectedGroupsChange: setSelectedGroups,
                                disabled: isProcessing
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 500,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FriendlyError, {
                message: error,
                bg: t.failBg,
                color: t.failText
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 513,
                columnNumber: 17
            }, this),
            mode === "sitemap" && crawlResult && liveFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SitemapDebug$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                crawl: crawlResult,
                filter: liveFilter,
                onScan: ()=>handleScanDiscovered("previous"),
                onScanImproved: ()=>handleScanDiscovered("improved"),
                scanning: isScanning,
                onCancel: handleCancelScan,
                scanLimit: scanLimit,
                onScanLimitChange: setScanLimit,
                maxScanLimit: availableCount,
                pipelineUsed: pipelineUsed,
                performanceMode: performanceMode,
                onPerformanceModeChange: setPerformanceMode,
                benchmarkRunMode: benchmarkRunMode,
                onBenchmarkRunModeChange: setBenchmarkRunMode,
                onResetBenchmark: resetBenchmark,
                hasBenchmarkData: !!(benchPrevious || benchImproved)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 517,
                columnNumber: 9
            }, this),
            results.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ResultsTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                results: results,
                scanTimer: scanTimer
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 537,
                columnNumber: 30
            }, this),
            (benchPrevious || benchImproved) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BenchmarkComparisonTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                previous: benchPrevious,
                improved: benchImproved,
                previousResults: prevResults,
                improvedResults: imprResults,
                onReset: resetBenchmark
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 540,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 451,
        columnNumber: 5
    }, this);
}
_s(Home, "PXxvJ3UXNArpRho/XeUC4frX1kw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c11 = Home;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Main");
__turbopack_context__.k.register(_c1, "HeaderRow");
__turbopack_context__.k.register(_c2, "HeaderText");
__turbopack_context__.k.register(_c3, "PageTitle");
__turbopack_context__.k.register(_c4, "PageSubtitle");
__turbopack_context__.k.register(_c5, "ThemeToggle");
__turbopack_context__.k.register(_c6, "ErrorBanner");
__turbopack_context__.k.register(_c7, "ErrorDetails");
__turbopack_context__.k.register(_c8, "FriendlyError");
__turbopack_context__.k.register(_c9, "CrawlSummary");
__turbopack_context__.k.register(_c10, "SummaryItem");
__turbopack_context__.k.register(_c11, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_12lw1h8._.js.map