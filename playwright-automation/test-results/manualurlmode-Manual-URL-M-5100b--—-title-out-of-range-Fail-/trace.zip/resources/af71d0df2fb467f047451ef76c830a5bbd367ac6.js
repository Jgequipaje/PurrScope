(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_12lw1h8._.js","static/chunks/node_modules_react-icons_ri_index_mjs_03oomsr._.js","static/chunks/node_modules_react-icons_lib_0mt5-rx._.js"],
    source: "dynamic"
});
